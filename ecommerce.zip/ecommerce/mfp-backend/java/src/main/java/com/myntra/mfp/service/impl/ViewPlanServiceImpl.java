/**
 *
 * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *
 * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 **/
package com.myntra.mfp.service.impl;

import com.myntra.commons.codes.StatusResponse;
import com.myntra.commons.exception.ManagerException;
import com.myntra.commons.service.impl.BaseServiceImpl;
import com.myntra.mfp.code.MfpErrorCode;
import com.myntra.mfp.code.MfpSuccessCode;
import com.myntra.mfp.entity.ViewPlan;
import com.myntra.mfp.entry.ViewPlanEntry;
import com.myntra.mfp.manager.ViewPlanManager;
import com.myntra.mfp.response.ViewPlanResponse;
import com.myntra.mfp.service.ViewPlanService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * @author Dhiraj
 * @date 23/11/17
 */
public class ViewPlanServiceImpl extends BaseServiceImpl<ViewPlanResponse, ViewPlanEntry, ViewPlan> implements ViewPlanService {


    private static final Logger LOGGER = LoggerFactory.getLogger(ViewPlanServiceImpl.class.getName());

    public ViewPlanServiceImpl() {
        super(MfpSuccessCode.SUCCESS, MfpSuccessCode.SUCCESS, MfpSuccessCode.SUCCESS, MfpErrorCode.RECORD_NOT_FOUND);
    }

    @Override
    protected ViewPlanResponse createResponse(List<ViewPlanEntry> entries) {
        return null;
    }

    @Override
    public String getHelloWorld() {
        return "MFP says Hello World !";
    }

    @Override
    public ViewPlanResponse viewAnualPlan() {
        ViewPlanResponse viewPlanResponse= new ViewPlanResponse();

        try {
            List<ViewPlanEntry> viewPlanEntries = ((ViewPlanManager)manager).viewAnualPlan();
            if(viewPlanEntries.isEmpty()) {
                viewPlanResponse.setStatus(new StatusResponse(MfpErrorCode.RECORDS_NOT_FOUND, StatusResponse.Type.SUCCESS, viewPlanEntries.size()));
            }
            viewPlanResponse.setData(viewPlanEntries);
            viewPlanResponse.setStatus(new StatusResponse(MfpSuccessCode.SUCCESS, StatusResponse.Type.SUCCESS, viewPlanEntries.size()));
        } catch (ManagerException e) {
            LOGGER.error("Error in view anual plan");
            viewPlanResponse.setStatus(e.getStatusResponse());
        }
        return viewPlanResponse;
    }

    @Override
    public ViewPlanResponse viewAnualPlan(ViewPlanEntry viewPlanEntry) {
        ViewPlanResponse viewPlanResponse= new ViewPlanResponse();
        try {
            List<ViewPlanEntry> viewPlanEntries = ((ViewPlanManager)manager).viewAnualPlan(viewPlanEntry);
            if(viewPlanEntries.isEmpty()) {
                viewPlanResponse.setStatus(new StatusResponse(MfpErrorCode.RECORDS_NOT_FOUND, StatusResponse.Type.SUCCESS, viewPlanEntries.size()));
            }
            viewPlanResponse.setData(viewPlanEntries);
            viewPlanResponse.setStatus(new StatusResponse(MfpSuccessCode.SUCCESS, StatusResponse.Type.SUCCESS, viewPlanEntries.size()));
        } catch (ManagerException e) {
            LOGGER.error("Error in view anual plan");
            viewPlanResponse.setStatus(e.getStatusResponse());
        }
        return viewPlanResponse;
    }
}
