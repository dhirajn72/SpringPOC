package com.myntra.mfp.utils;
import com.myntra.mfp.entry.*;
import com.myntra.mfp.enums.Formulas;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;

/**
 * @Author-Dinesh
 * @Date-30-11-2017
 */

public class SalesFormulae {

    private ExpressionParser parser = null;

    public Double calculateUnitsSold(double v, double v1) {
        UnitsSold unitsSold = new UnitsSold();
        unitsSold.setMrp(v);
        unitsSold.setUnit(v1);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.UNITS_SOLD.formula());
        return exp.getValue(unitsSold, Double.class);
    }

    public Double calculateAisp(double v, double v1) {
        Aisp aisp = new Aisp();
        aisp.setGmv(v);
        aisp.setUnits_sold(v1);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.AISP.formula());
        return exp.getValue(aisp, Double.class);
    }

    public Double calculateMrpExTaxOR(double v, double v1) {
        MrpExTax_OR mrpextax = new MrpExTax_OR();
        mrpextax.setMrp(v);
        mrpextax.setTax_percentage(v1);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.MRPEXTAXOR.formula());
        return exp.getValue(mrpextax, Double.class);
    }

    public Double calculateMrpExTaxSOR(double v, double v1) {
        MrpExTax_OR mrpextax = new MrpExTax_OR();
        mrpextax.setMrp(v);
        mrpextax.setTax_percentage(v1);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.MRPEXTAXSOR.formula());
        return exp.getValue(mrpextax, Double.class);
    }


    public Double calculateVfOR(double v, double v1) {
        VfF_OR vf1 = new VfF_OR();
        vf1.setVf_percentage(v);
        vf1.setMrp(v1);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.VF_OR.formula());
        return exp.getValue(vf1, Double.class);
    }

    public Double calculateVfSOR(double v, double v1) {
        VfF_SOR vf2 = new VfF_SOR();
        vf2.setVf_percentage(v);
        vf2.setIpp(v1);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.VF_SOR.formula());
        return exp.getValue(vf2, Double.class);

    }

    public Double calculateBmPercentNotionalSOR(double v, double v1, double v2) {
        BmPercentageNotional_SOR bmf1 = new BmPercentageNotional_SOR();
        bmf1.setIpp(v);
        bmf1.setVf(v1);
        bmf1.setMrp_ex_tax(v2);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.BM_PERCENTAGE_NOTIONAL_SOR.formula());
        return exp.getValue(bmf1, Double.class);
    }

    public Double calculateBmPercentNotionalOR(double v, double v1) {
        BmPercentageNotional_OR bmf2 = new BmPercentageNotional_OR();
        bmf2.setIpp(v);
        bmf2.setMrp_ex_tax(v1);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.BM_PERCENTAGE_NOTIONAL_OR.formula());
        return exp.getValue(bmf2, Double.class);
    }

    public Double calculateCogs(double v, double v1) {
        Cogs cogs = new Cogs();
        cogs.setIpp(v);
        cogs.setVf(v1);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.COGS.formula());
        return exp.getValue(cogs, Double.class);
    }

    public Double calculateGmPercent(double v, double v1, double v2) {
        GmPercentage gmPercent = new GmPercentage();
        gmPercent.setCogs(v);
        gmPercent.setTax_percentage(v1);
        gmPercent.setGmv(v2);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.GM_PERCENTAGE.formula());
        return exp.getValue(gmPercent, Double.class);
    }

    public Double calculateRgmUnit(double v, double v1, double v2) {
        RgmUnit rgmUnit = new RgmUnit();
        rgmUnit.setGm_percentage(v);
        rgmUnit.setAisp(v1);
        rgmUnit.setTax_percentage(v2);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.RGM_UNIT.formula());
        return exp.getValue(rgmUnit, Double.class);
    }

    public Double calculateMrp(double v, double v1, double v2, double v3, double v4) {
        Mrp mrp = new Mrp();
        mrp.setGmv(v);
        mrp.setVf(v1);
        mrp.setCf(v2);
        mrp.setTax_recovery_percentage(v3);
        mrp.setTax_Revenue_percentage(v4);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.MRP.formula());
        return exp.getValue(mrp, Double.class);
    }
    

    public Double calculateIppOR(double v, double v1, double v2) {
        Ipp_OR ipp_or = new Ipp_OR();
        ipp_or.setMrpPerTax(v);
        ipp_or.setBm_Percentage(v1);
        ipp_or.setMrp(v2);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.IPP_OR.formula());
        return exp.getValue(ipp_or,Double.class);
    }

    public Double calculateIppSOR(double v, double v1, double v2) {
        Ipp_SOR ipp_sor=new Ipp_SOR();
        ipp_sor.setMrpPerTax(v);
        ipp_sor.setBm_Percentage(v1);
        ipp_sor.setMrp(v2);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.IPP_SOR.formula());
        return exp.getValue(ipp_sor,Double.class);
    }

    public Double calculateTaxOR(double v, double v1) {
        Tax_OR tax_or = new Tax_OR();
        tax_or.setGmv(v);
        tax_or.setTaxRevenuepercentage(v1);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.TAX_OR.formula());
        return exp.getValue(tax_or,Double.class);

    }

    public Double calculateTaxSOR(double v, double v1) {
        Tax_SOR tax_sor = new Tax_SOR();
        tax_sor.setGmv(v);
        tax_sor.setTaxRevenuepercentage(v1);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.TAX_OR.formula());
        return exp.getValue(tax_sor,Double.class);
    }
}

