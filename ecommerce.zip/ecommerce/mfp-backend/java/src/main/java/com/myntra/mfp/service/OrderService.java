/**
 *
 * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *
 * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 **/
package com.myntra.mfp.service;


import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.*;

@Path("/order")
public interface OrderService {

    @GET
    @Produces("text/plain")
    @Path("/helloWorld")
    public String getHelloWorld();

}
