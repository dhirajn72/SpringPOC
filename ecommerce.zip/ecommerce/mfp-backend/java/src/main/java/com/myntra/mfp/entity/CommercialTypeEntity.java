/**
 *
 * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *
 * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 **/

package com.myntra.mfp.entity;

import com.myntra.commons.entities.BaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;

/**
 * @author Dhiraj
 * @date 29/11/17
 */

@Entity
@Table(name ="ct_mstr" )
public class CommercialTypeEntity extends BaseEntity {

    @Column(name = "ct_name")
    private String ct_name;


    @Column(name = "last_modified_by")
    private String last_modified_by;

    public CommercialTypeEntity() {
    }

    public CommercialTypeEntity(Long id, String createdBy, Date createdOn, String ct_name, String last_modified_by) {
        super(id, createdBy, createdOn);
        this.ct_name = ct_name;
        this.last_modified_by = last_modified_by;
    }

    public String getCt_name() {
        return ct_name;
    }

    public void setCt_name(String ct_name) {
        this.ct_name = ct_name;
    }

    public String getLast_modified_by() {
        return last_modified_by;
    }

    public void setLast_modified_by(String last_modified_by) {
        this.last_modified_by = last_modified_by;
    }
}
