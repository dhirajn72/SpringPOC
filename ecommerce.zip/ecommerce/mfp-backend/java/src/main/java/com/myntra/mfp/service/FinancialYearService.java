package com.myntra.mfp.service;

import com.myntra.commons.service.BaseService;
import com.myntra.mfp.entity.FinancialYearEntity;
import com.myntra.mfp.entry.FinalcialYearEntry;
import com.myntra.mfp.response.FinancialYearResponse;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

/**
 * @author Dhiraj
 * @date 04/12/17
 */


@Path("/years")
public interface FinancialYearService extends BaseService<FinancialYearResponse,FinalcialYearEntry,FinancialYearEntity>{

    @GET
    @Path("/getfinancialyears")
    @Produces({"application/json","application/xml"})
    @Consumes({"application/json","application/xml"})
    FinancialYearResponse getAllFinancialYears();
}

