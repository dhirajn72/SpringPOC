package com.myntra.mfp.utils;

import com.myntra.mfp.entry.*;
import com.myntra.mfp.enums.Formulas;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;

public class InventoryFormulae {

    private ExpressionParser parser = null;

    public long calculateFreshness(int i, int i1) {
        Freshness freshness = new Freshness();
        freshness.setNew_style(i);
        freshness.setLive_styles(i1);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.FRESHNESS.formula());
        return exp.getValue(freshness, Long.class);
    }

    public long calculateStr(int i, int i1) {
        Str str = new Str();
        str.setGross_units_sold(i);
        str.setClosing(i1);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.STR.formula());
        return exp.getValue(str, Long.class);
    }

    public long calculateInwardedUnits(int i, int i1, int i2, int i3, int i4, int i5) {
        InwardedUnits inwardedUnits = new InwardedUnits();
        inwardedUnits.setClosing_inv(i);
        inwardedUnits.setOpening_inv(i1);
        inwardedUnits.setNew_units_sold(i2);
        inwardedUnits.setRtv(i3);
        inwardedUnits.setRet_restock(i4);
        inwardedUnits.setRto_restock(i5);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.INWARDED_UNITS.formula());
        return exp.getValue(inwardedUnits, Long.class);
    }

    public long calculateClosingInventory(int i, int i1) {
        ClosingInventory closingInventory = new ClosingInventory();
        closingInventory.setDoh(10);
        closingInventory.setNet_units_sold(50);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.CLOSING_INV.formula());
        return exp.getValue(closingInventory, Long.class);
    }

    public long calculateNetUnitsSold(int i, int i1, int i2) {
        NetUnitsSold netUnitsSold = new NetUnitsSold();
        netUnitsSold.setUnits_sold_in_days(i);
        netUnitsSold.setReturn_restocking(i1);
        netUnitsSold.setRto_restocking(i2);
        parser = new SpelExpressionParser();
        Expression exp = parser.parseExpression(Formulas.NET_UNITS_SOLD.formula());
        return exp.getValue(netUnitsSold, Long.class);
    }

}
