/*
 *
 *  *  Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved. MYNTRA
 *  *  PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.manager.impl;

import com.myntra.commons.exception.ManagerException;
import com.myntra.commons.manager.impl.BaseManagerImpl;
import com.myntra.mfp.dao.AnnualPlanDao;
import com.myntra.mfp.entity.*;
import com.myntra.mfp.entry.*;
import com.myntra.mfp.manager.ViewAnnualPlanManager;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author Dhiraj
 * @date 30/11/17
 */
public class ViewAnnualPlanManagerImpl extends BaseManagerImpl<AnnualPlanEntry, AnnualPlanEntity> implements ViewAnnualPlanManager {
    @Override
    @Transactional(Transactional.TxType.REQUIRED)
    public List<AnnualPlanEntry> viewDetailedAnualPlan(ViewPlanEntry viewPlanEntry) throws ManagerException {
        List<AnnualPlanEntry> planEntries = new ArrayList<AnnualPlanEntry>();
        List<AnnualPlanEntity> planEntities = ((AnnualPlanDao) getDao()).viewDetailedAnualPlan(viewPlanEntry);
        for (AnnualPlanEntity annualPlanEntity : planEntities) {
            AnnualPlanEntry planEntry = convertEntityToEntry(annualPlanEntity);
            planEntries.add(planEntry);
        }
        return planEntries;
    }



    private AnnualPlanEntry convertEntityToEntry(AnnualPlanEntity viewPlan) {
        AnnualPlanEntry anualPlanEntry = super.convertToEntry(viewPlan);
        anualPlanEntry.setFinalcialYearEntry(convertEntityToEntry(viewPlan.getFinalcialYearEntity()));
        anualPlanEntry.setChannelEntry(convertEntityToEntry(viewPlan.getChannelEntity()));
        anualPlanEntry.setSourceEntry(convertEntityToEntry(viewPlan.getSourceEntity()));
        anualPlanEntry.setBusinessUnitEntry(convertEntityToEntry(viewPlan.getBusinessUnitEntity()));
        anualPlanEntry.setBrandGroupEntry(convertEntityToEntry(viewPlan.getBrandGroupEntity()));
        anualPlanEntry.setBrandEntry(convertEntityToEntry(viewPlan.getBrandEntity()));
        anualPlanEntry.setMasterCategoryEntry(convertEntityToEntry(viewPlan.getMasterCategoryEntity()));
        anualPlanEntry.setGenderEntry(convertEntityToEntry(viewPlan.getGenderEntity()));
        anualPlanEntry.setArticleEntry(convertEntityToEntry(viewPlan.getArticleEntity()));
        anualPlanEntry.setCommercialTypeEntry(convertEntityToEntry(viewPlan.getCommercialTypeEntity()));
        anualPlanEntry.setPricePointEntry(convertEntityToEntry(viewPlan.getPricePointEntity()));
        return anualPlanEntry;
    }

    private FinalcialYearEntry convertEntityToEntry(FinancialYearEntity finalcialYearEntity) {
        return new FinalcialYearEntry(finalcialYearEntity.getId(), finalcialYearEntity.getCreatedBy(),finalcialYearEntity.getCreatedOn(), finalcialYearEntity.getLastModifiedOn(), finalcialYearEntity.getFinancial_year(), finalcialYearEntity.getLast_modified_by());
    }

    private ChannelEntry convertEntityToEntry(ChannelEntity channelEntity) {
        return new ChannelEntry(channelEntity.getId(), channelEntity.getCreatedBy(), channelEntity.getCreatedOn(), channelEntity.getLastModifiedOn(), channelEntity.getChannel_name(), channelEntity.getLast_modified_by());
    }

    private SourceEntry convertEntityToEntry(SourceEntity sourceEntity) {
        return new SourceEntry(sourceEntity.getId(), sourceEntity.getCreatedBy(), sourceEntity.getCreatedOn(), sourceEntity.getLastModifiedOn(), sourceEntity.getSource_name(), sourceEntity.getLast_modified_by());
    }

    private BusinessUnitEntry convertEntityToEntry(BusinessUnitEntity businessUnitEntity) {
        return new BusinessUnitEntry(businessUnitEntity.getId(), businessUnitEntity.getCreatedBy(), businessUnitEntity.getCreatedOn(), businessUnitEntity.getLastModifiedOn(), businessUnitEntity.getBu_name(), businessUnitEntity.getLast_modified_by());
    }

    private BrandGroupEntry convertEntityToEntry(BrandGroupEntity brandGroupEntity) {
        return new BrandGroupEntry(brandGroupEntity.getId(), brandGroupEntity.getCreatedBy(), brandGroupEntity.getCreatedOn(), brandGroupEntity.getLastModifiedOn(), brandGroupEntity.getBrnd_grp_name(), brandGroupEntity.getLast_modified_by());
    }

    private BrandEntry convertEntityToEntry(BrandEntity brandEntity) {
        return new BrandEntry(brandEntity.getId(), brandEntity.getCreatedBy(), brandEntity.getCreatedOn(), brandEntity.getLastModifiedOn(), brandEntity.getBrnd_name(), brandEntity.getLast_modified_by());
    }

    private MasterCategoryEntry convertEntityToEntry(MasterCategoryEntity masterCategoryEntity) {
        return new MasterCategoryEntry(masterCategoryEntity.getId(), masterCategoryEntity.getCreatedBy(), masterCategoryEntity.getCreatedOn(), masterCategoryEntity.getLastModifiedOn(), masterCategoryEntity.getMst_cat_name(), masterCategoryEntity.getLast_modified_by());
    }

    private GenderEntry convertEntityToEntry(GenderEntity genderEntity) {
        return new GenderEntry(genderEntity.getId(), genderEntity.getCreatedBy(), genderEntity.getCreatedOn(), genderEntity.getLastModifiedOn(), genderEntity.getGender_name(), genderEntity.getLast_modified_by());
    }

    private ArticleEntry convertEntityToEntry(ArticleEntity articleEntity) {
        return new ArticleEntry(articleEntity.getId(), articleEntity.getCreatedBy(), articleEntity.getCreatedOn(), articleEntity.getLastModifiedOn(), articleEntity.getArticle_name(), articleEntity.getLast_modified_by());
    }

    private CommercialTypeEntry convertEntityToEntry(CommercialTypeEntity commercialTypeEntity) {
        return new CommercialTypeEntry(commercialTypeEntity.getId(), commercialTypeEntity.getCreatedBy(), commercialTypeEntity.getCreatedOn(), commercialTypeEntity.getLastModifiedOn(), commercialTypeEntity.getCt_name(), commercialTypeEntity.getLast_modified_by());
    }

    private PricePointEntry convertEntityToEntry(PricePointEntity pricePointEntity) {
        return new PricePointEntry(pricePointEntity.getId(), pricePointEntity.getCreatedBy(), pricePointEntity.getCreatedOn(), pricePointEntity.getLastModifiedOn(), pricePointEntity.getPp_range(), pricePointEntity.getLast_modified_by());
    }

/*
DONT Remove this ! This method implementation is in progress !


    @Override
    public AnnualPlanEntry saveAnnualPlan(AnnualPlanEntry annualPlanEntry) {

        AnnualPlanEntity ape= new AnnualPlanEntity(annualPlanEntry.getId(), annualPlanEntry.getCreatedBy(), annualPlanEntry.getCreatedOn(), annualPlanEntry.getGmv(), annualPlanEntry.getMrp_per_unit(),annualPlanEntry.getAisp(), annualPlanEntry.getCf(), annualPlanEntry.getTax_recovery(), annualPlanEntry.getBm_contractual(), annualPlanEntry.getBm_type(), annualPlanEntry.getVf_contractual(),annualPlanEntry.getRoyalty(),annualPlanEntry.getTax(), annualPlanEntry.getMrp(), annualPlanEntry.getMrp_ex_tax(), annualPlanEntry.getIpp(), annualPlanEntry.getBm_notional(),annualPlanEntry.getCogs(), annualPlanEntry.getGm_percent(), annualPlanEntry.getForward_doh(), annualPlanEntry.getOpening_inventory(), annualPlanEntry.getUnits_sold(), annualPlanEntry.getCurrent_inventory(), annualPlanEntry.getNew_styles_added(),annualPlanEntry.getLive_styles_month_end(), annualPlanEntry.getLast_modified_by(), annualPlanEntry.getDate_ap(),
                convertEntryToEntity(annualPlanEntry.getFinalcialYearEntry()), convertEntryToEntity(annualPlanEntry.getChannelEntry()), convertEntryToEntity(annualPlanEntry.getSourceEntry()), BusinessUnitEntity businessUnitEntity, BrandGroupEntity brandGroupEntity, BrandEntity brandEntity, MasterCategoryEntity masterCategoryEntity, GenderEntity genderEntity, ArticleEntity articleEntity, CommercialTypeEntity commercialTypeEntity, PricePointEntity pricePointEntity) {


       // ((AnnualPlanDao)this.getDao()).saveAnnualPlan(ape);
        return null;

    }


    private FinancialYearEntity convertEntryToEntity(FinalcialYearEntry finalcialYearEntry){
        return new FinancialYearEntity(finalcialYearEntry.getId(), finalcialYearEntry.getCreatedBy(), finalcialYearEntry.getCreatedOn(), finalcialYearEntry.getFinancial_year(), finalcialYearEntry.getLast_modified_by());
    }
    private ChannelEntity convertEntryToEntity(ChannelEntry channelEntry){
        return new ChannelEntity(channelEntry.getId(), channelEntry.getCreatedBy(), channelEntry.getCreatedOn(), channelEntry.getChannel_name(), channelEntry.getLast_modified_by()) ;
    }
    private SourceEntity convertEntryToEntity(SourceEntry sourceEntry){
        return new SourceEntity(sourceEntry.getId(), sourceEntry.getCreatedBy(), sourceEntry.getCreatedOn(), sourceEntry.getSource_name(),sourceEntry.getLast_modified_by());
    }

    */


}
