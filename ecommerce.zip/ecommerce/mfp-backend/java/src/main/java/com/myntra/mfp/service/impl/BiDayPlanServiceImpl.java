package com.myntra.mfp.service.impl;
import com.myntra.commons.exception.DaoException;
import com.myntra.commons.service.impl.BaseServiceImpl;
import com.myntra.mfp.entity.SalesAnnualPlanEntity;
import com.myntra.mfp.entity.BiDayPlanEntity;
import com.myntra.mfp.entry.BiDayPlanEntry;
import com.myntra.mfp.manager.SalesAnnualPlanManager;
import com.myntra.mfp.manager.BiDayPlanManager;
import com.myntra.mfp.response.BiDayPlanResponse;
import com.myntra.mfp.service.BiDayPlanService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * @Author-Dinesh
 * @Date-30-11-2017
 */

public class BiDayPlanServiceImpl extends BaseServiceImpl<BiDayPlanResponse,BiDayPlanEntry,BiDayPlanEntity> implements BiDayPlanService {

    public static final Logger LOGGER = LoggerFactory.getLogger(BiDayPlanServiceImpl.class);
    private BiDayPlanManager biDayPlanManager;
    private SalesAnnualPlanManager annualPlanManager;

    public void setBiDayPlanManager(BiDayPlanManager biDayPlanManager) {
        this.biDayPlanManager = biDayPlanManager;
    }

    public void setAnnualPlanManager(SalesAnnualPlanManager annualPlanManager) {
        this.annualPlanManager = annualPlanManager;
    }



    public BiDayPlanServiceImpl() {
        super(null, null, null, null);
    }



    @Override
    public Double createAnnualPlan(Double AOPTarget) {

        //Setting insdexes to get value from Db into chunks.
        int startIndex=1;
        int  maxResult=90;

       Double sumOfGmv =  this.biDayPlanManager.getTotalSumOfGmvOfHistoricData();
        while(true){

            List<SalesAnnualPlanEntity> entityList =this.biDayPlanManager.getAnnualPlanWithUpdatedMetrics(AOPTarget,sumOfGmv, (startIndex-1)*maxResult,  maxResult);
            if(entityList.size()==0) break;
            startIndex++;
            try {
                this.annualPlanManager.createBulkRecords(entityList);
            } catch (DaoException e) {
                LOGGER.error("Error while getting the records" + e.getMessage());
            }

        }


        return 0.0;
    }

    @Override
    protected BiDayPlanResponse createResponse(List<BiDayPlanEntry> list) {
        return null;
    }

    public String getHello()
    {

        return "Hello World";
    }
}
