/*
 *
 *  *
 *  * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *  *
 *  * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.dao.impl;

import com.myntra.commons.dao.impl.BaseDAOImpl;
import com.myntra.mfp.dao.ChannelDao;
import com.myntra.mfp.entity.ChannelEntity;

import javax.persistence.Query;
import java.util.List;

/**
 * @author Dhiraj
 * @date 04/12/17
 */
public class ChannelDaoImpl extends BaseDAOImpl<ChannelEntity> implements ChannelDao {
    @Override
    public List<ChannelEntity> getAllChannels() {
        Query query =this.getEntityManager(false).createNamedQuery(ChannelEntity.LIST_CHANNELS);
        return query.getResultList();
    }
}
