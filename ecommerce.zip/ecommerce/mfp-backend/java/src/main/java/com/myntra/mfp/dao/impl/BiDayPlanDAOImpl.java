package com.myntra.mfp.dao.impl;

import com.myntra.commons.dao.impl.BaseDAOImpl;
import com.myntra.mfp.dao.BiDayPlanDAO;
import com.myntra.mfp.entity.BiDayPlanEntity;

/**
 * @Author-Dinesh
 * @Date-30-11-2017
 */


public class BiDayPlanDAOImpl extends BaseDAOImpl<BiDayPlanEntity> implements BiDayPlanDAO {

}
