/*
 *
 *  *
 *  * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *  *
 *  * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.dao.impl;

import com.myntra.commons.dao.impl.BaseDAOImpl;
import com.myntra.mfp.dao.FinancialYearDao;
import com.myntra.mfp.entity.FinancialYearEntity;

import javax.persistence.Query;
import java.util.List;

/**
 * @author Dhiraj
 * @date 04/12/17
 */
public class FinancialYearDaoImpl extends BaseDAOImpl<FinancialYearEntity>  implements FinancialYearDao{


    @Override
    public List<FinancialYearEntity> getAllYears() {
        Query query =getEntityManager(false).createNamedQuery(FinancialYearEntity.GET_ALL_FINANCIAL_YEAR);
        return query.getResultList();
    }
}
