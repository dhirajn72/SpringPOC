/*
 *
 *  *  Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved. MYNTRA
 *  *  PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.dao;

import com.myntra.commons.dao.BaseDAO;
import com.myntra.mfp.entity.FinancialYearEntity;

import java.util.List;

/**
 * @author Dhiraj
 * @date 04/12/17
 */
public interface FinancialYearDao extends BaseDAO<FinancialYearEntity> {
    List<FinancialYearEntity> getAllYears();
}
