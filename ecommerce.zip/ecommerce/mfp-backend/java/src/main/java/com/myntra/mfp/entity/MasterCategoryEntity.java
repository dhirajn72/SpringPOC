/**
 *
 * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *
 * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 **/

package com.myntra.mfp.entity;

import com.myntra.commons.entities.BaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;

/**
 * @author Dhiraj
 * @date 29/11/17
 */


@Entity
@Table(name = "mst_cat_mstr")
public class MasterCategoryEntity extends BaseEntity{


    @Column(name = "mst_cat_name")
    private String mst_cat_name;

    @Column(name = "last_modified_by")
    private String last_modified_by;

    public MasterCategoryEntity() {
    }

    public MasterCategoryEntity(Long id, String createdBy, Date createdOn, String mst_cat_name, String last_modified_by) {
        super(id, createdBy, createdOn);
        this.mst_cat_name = mst_cat_name;
        this.last_modified_by = last_modified_by;
    }

    public String getMst_cat_name() {
        return mst_cat_name;
    }

    public void setMst_cat_name(String mst_cat_name) {
        this.mst_cat_name = mst_cat_name;
    }

    public String getLast_modified_by() {
        return last_modified_by;
    }

    public void setLast_modified_by(String last_modified_by) {
        this.last_modified_by = last_modified_by;
    }
}
