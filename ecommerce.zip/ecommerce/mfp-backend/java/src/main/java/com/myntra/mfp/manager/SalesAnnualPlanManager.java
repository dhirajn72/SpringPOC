package com.myntra.mfp.manager;
import com.myntra.commons.exception.DaoException;
import com.myntra.commons.manager.BaseManager;
import com.myntra.mfp.entity.SalesAnnualPlanEntity;
import com.myntra.mfp.entry.SalesAnnualPlanEntry;

import java.util.List;

/**
 * @Author-Dinesh
 * @Date-30-11-2017
 */

public interface SalesAnnualPlanManager extends BaseManager<SalesAnnualPlanEntry,SalesAnnualPlanEntity> {
    void createBulkRecords(List<SalesAnnualPlanEntity> entityList) throws DaoException;
}
