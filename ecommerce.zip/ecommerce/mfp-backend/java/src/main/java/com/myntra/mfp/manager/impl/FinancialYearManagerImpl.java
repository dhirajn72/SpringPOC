/*
 *
 *  *
 *  * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *  *
 *  * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.manager.impl;

import com.myntra.commons.manager.impl.BaseManagerImpl;
import com.myntra.mfp.dao.FinancialYearDao;
import com.myntra.mfp.entity.FinancialYearEntity;
import com.myntra.mfp.entry.FinalcialYearEntry;
import com.myntra.mfp.manager.FinancialYearManager;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Dhiraj
 * @date 04/12/17
 */
public class FinancialYearManagerImpl extends BaseManagerImpl<FinalcialYearEntry,FinancialYearEntity>  implements FinancialYearManager{

    @Override
    public List<FinalcialYearEntry> getAllYears() {
         List<FinancialYearEntity> financialYearEntities = ((FinancialYearDao)getDao()).getAllYears();
         List<FinalcialYearEntry> finalcialYearEntries = new ArrayList<FinalcialYearEntry>();
         for(FinancialYearEntity entity:financialYearEntities){
             finalcialYearEntries.add(super.convertToEntry(entity));
         }
        return finalcialYearEntries;
    }
}
