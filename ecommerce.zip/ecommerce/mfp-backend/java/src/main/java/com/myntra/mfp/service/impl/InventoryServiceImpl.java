package com.myntra.mfp.service.impl;

import com.myntra.mfp.service.InventoryService;
import com.myntra.mfp.utils.InventoryFormulae;
import com.myntra.mfp.utils.SalesFormulae;

public class InventoryServiceImpl implements InventoryService{

    private InventoryFormulae inventoryformulae;

    public void setInventoryformulae(InventoryFormulae inventoryformulae) {
        this.inventoryformulae = inventoryformulae;
    }

    @Override
    public String getInventoryCalculations() {

            long netunitssold = inventoryformulae.calculateNetUnitsSold(10,3,2);
            long closinginv = inventoryformulae.calculateClosingInventory(10,2);
            long inwardedUnits = inventoryformulae.calculateInwardedUnits(2,3,4,5,6,7);
            long str = inventoryformulae.calculateStr(15,20);
            long freshness = inventoryformulae.calculateFreshness(10,20);
            return "result : "+netunitssold+" --- "+closinginv+" --- "+inwardedUnits+" --- "+str+" --- "+freshness;

    }
}
