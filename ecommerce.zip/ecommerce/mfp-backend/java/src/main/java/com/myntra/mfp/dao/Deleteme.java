/*
 *
 *  *
 *  * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *  *
 *  * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.dao;

import java.time.LocalDate;
import java.time.Year;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * @author Dhiraj
 * @date 08/12/17
 */
public class Deleteme {
    public static void main(String[] args){


        Date da1 = new Date();
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(da1);
        cal1.add(Calendar.DATE, -1);
        da1 = cal1.getTime();
        System.out.println(da1);
        System.out.println(cal1);


        Date da2 = new Date();
        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(da2);
        cal2.add(Calendar.YEAR, -1);
        da2 = cal2.getTime();
        System.out.println(da2);
        System.out.println(cal2);


        long diff = da2.getTime() - da1.getTime();
        System.out.println(TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS));

        System.out.println("************");






























        /*   curl -X POST \
       http://54.251.8.187:8080/udp-api/rest/v1/reports/fact_product_profile_extended/daily/direct/getMetricsGroupedByDimensionWithFilters \
       -H 'accept: application/json' \
       -H 'apikey: PSF0W2VJ' \
       -H 'cache-control: no-cache' \
       -H 'content-type: application/x-www-form-urlencoded' \
       -H 'postman-token: 4d54a673-d5bb-f1e3-6277-5319aa661da5' \
       -H 'username: enterYourUsername@myntra.com' \
       -d
       'metrics=doh_value_incl_po_excl_ro_last7%3ADESC%2Clast_7days_rgm_per_unit%3ADESC&dimensions=brand%2Carticle_type&fromTime=1449340200000&toTime=1449426600000&limit=1000&offset=0&sendTotal=true&invalidateBackendCache=true&defaultDateColumn=date&seriesLimit=0&dimensionsValueMap=brand%CE%B1Puma%CE%B1IN%CE%B1ONLY_SHOW%CE%B2article_type%CE%B1Sweatshirts%CE%B1IN%CE%B1ONLY_SHOW&connector=AND'



         metrics=gmv:DESC,last_7days_rgm_per_unit:DESC&dimensions=brand,article_type&fromTime=1449340200000&toTime=1449426600000&limit=1000&offset=0&sendTotal=true&invalidateBackendCache=true&defaultDateColumn=date&seriesLimit=0&dimensionsValueMap=brandαPumaαINαONLY_SHOWβarticle_typeαSweatshirtsαINαONLY_SHOW&connector=AND


         */

    }
}
