/**
 *
 * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *
 * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 **/


package com.myntra.mfp.entity;

import com.myntra.commons.entities.BaseEntity;

import javax.persistence.*;
import java.util.Date;

/**
 * @author Dhiraj
 * @date 29/11/17
 */


@Entity
@Table(name = "brnd_grp_mstr")
public class BrandGroupEntity extends BaseEntity{


    @Column(name = "brnd_grp_name")
    private String brnd_grp_name;

    @Column(name = "last_modified_by")
    private String last_modified_by;


    public BrandGroupEntity() {
    }

    public BrandGroupEntity(Long id, String createdBy, Date createdOn, String brnd_grp_name, String last_modified_by) {
        super(id, createdBy, createdOn);
        this.brnd_grp_name = brnd_grp_name;
        this.last_modified_by = last_modified_by;
    }

    public String getBrnd_grp_name() {
        return brnd_grp_name;
    }

    public void setBrnd_grp_name(String brnd_grp_name) {
        this.brnd_grp_name = brnd_grp_name;
    }

    public String getLast_modified_by() {
        return last_modified_by;
    }

    public void setLast_modified_by(String last_modified_by) {
        this.last_modified_by = last_modified_by;
    }
}
