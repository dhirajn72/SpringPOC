/**
 *
 * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *
 * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 **/

package com.myntra.mfp.entity;

import com.myntra.commons.entities.BaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;

/**
 * @author Dhiraj
 * @date 29/11/17
 */


@Entity
@Table(name = "brnd_mstr")
public class BrandEntity extends BaseEntity{


    @Column(name = "brnd_name")
    private String brnd_name;

    @Column(name = "last_modified_by")
    private String last_modified_by;

    public BrandEntity() {
    }

    public BrandEntity(Long id, String createdBy, Date createdOn, String brnd_name, String last_modified_by) {
        super(id, createdBy, createdOn);
        this.brnd_name = brnd_name;
        this.last_modified_by = last_modified_by;
    }

    public String getBrnd_name() {
        return brnd_name;
    }

    public void setBrnd_name(String brnd_name) {
        this.brnd_name = brnd_name;
    }

    public String getLast_modified_by() {
        return last_modified_by;
    }

    public void setLast_modified_by(String last_modified_by) {
        this.last_modified_by = last_modified_by;
    }
}
