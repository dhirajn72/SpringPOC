/**
 *
 * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *
 * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 **/

package com.myntra.mfp.entity;

import com.myntra.commons.entities.BaseEntity;

import javax.persistence.*;
import java.util.Date;

/**
 * @author Dhiraj
 * @date 29/11/17
 */


@Entity
@Table(name = "channel_mstr")
@NamedQueries(value = {
        @NamedQuery(name = ChannelEntity.LIST_CHANNELS, query = "select channels from ChannelEntity channels")
})
public class ChannelEntity  extends BaseEntity{

    public static final String LIST_CHANNELS = "FindAllChannels";

    @Column(name = "channel_name")
    private String channel_name;

    @Column(name = "last_modified_by")
    private String last_modified_by;

    public ChannelEntity() {
    }

    public ChannelEntity(Long id, String createdBy, Date createdOn, String channel_name, String last_modified_by) {
        super(id, createdBy, createdOn);
        this.channel_name = channel_name;
        this.last_modified_by = last_modified_by;
    }

    public String getChannel_name() {
        return channel_name;
    }

    public void setChannel_name(String channel_name) {
        this.channel_name = channel_name;
    }

    public String getLast_modified_by() {
        return last_modified_by;
    }

    public void setLast_modified_by(String last_modified_by) {
        this.last_modified_by = last_modified_by;
    }
}
