package com.myntra.mfp.service.impl;

import com.myntra.commons.exception.DaoException;
import com.myntra.mfp.entity.AnnualPlanModel;
import com.myntra.mfp.manager.AggregationServiceManager;
import com.myntra.mfp.service.AggregationService;
import marvin.client.entry.UserViewEntry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class AggregationServiceImpl implements AggregationService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AggregationServiceImpl.class);

    private AggregationServiceManager manager;


    public void setManager(AggregationServiceManager manager) {
        this.manager = manager;
    }

    @Override
    public List<AnnualPlanModel> getUserView(UserViewEntry userViewEntry, Integer page, Integer pageLimit) {
        LOGGER.info("Started to get the user views >>>>>>  "+userViewEntry.getUserView());
        Map<String,List<AnnualPlanModel>> map = new LinkedHashMap<>();
        List<AnnualPlanModel> annualPlanModelList = new ArrayList<>();
        try {
            if(userViewEntry.getCalendar().equalsIgnoreCase("month")){

                annualPlanModelList = manager.getAggregationOnUserAxis(userViewEntry, page, pageLimit);

            }
        } catch (DaoException e) {
            e.printStackTrace();
            LOGGER.error(e.getMessage());
        } catch (SQLException e) {
            e.printStackTrace();
            LOGGER.error(e.getMessage());
        }
        return annualPlanModelList;
    }
}
