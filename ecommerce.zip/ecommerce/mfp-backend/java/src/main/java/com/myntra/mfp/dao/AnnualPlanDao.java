/*
 *
 *  *  Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved. MYNTRA
 *  *  PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.dao;

import com.myntra.commons.dao.BaseDAO;
import com.myntra.mfp.entity.AnnualPlanEntity;
import com.myntra.mfp.entity.FinancialYearEntity;
import com.myntra.mfp.entry.ViewPlanEntry;

import java.util.List;

/**
 * @author Dhiraj
 * @date 30/11/17
 */
public interface AnnualPlanDao  extends BaseDAO<AnnualPlanEntity> {
    List<AnnualPlanEntity> viewDetailedAnualPlan(ViewPlanEntry viewPlanEntry);
}
