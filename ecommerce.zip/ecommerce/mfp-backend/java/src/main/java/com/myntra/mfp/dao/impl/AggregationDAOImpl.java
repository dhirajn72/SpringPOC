package com.myntra.mfp.dao.impl;

import com.myntra.commons.dao.impl.BaseDAOImpl;
import com.myntra.mfp.dao.AggregationDAO;
import com.myntra.mfp.entity.AnnualPlanEntity;

public class AggregationDAOImpl extends BaseDAOImpl<AnnualPlanEntity> implements AggregationDAO {

}
