/**
 *
 * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *
 * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 **/
package com.myntra.mfp.dao;

import com.myntra.commons.dao.BaseDAO;
import com.myntra.mfp.entity.ViewPlan;
import com.myntra.mfp.entry.ViewPlanEntry;

import java.util.List;

/**
 * @author Dhiraj
 * @date 24/11/17
 */
public interface ViewPlanDao extends BaseDAO<ViewPlan> {

    List<ViewPlan> getAllAnnualPlans();
    List<ViewPlan> getAllAnnualPlans(ViewPlanEntry viewPlanEntry);



}
