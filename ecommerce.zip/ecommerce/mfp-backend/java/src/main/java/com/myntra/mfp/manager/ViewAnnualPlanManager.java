/*
 *
 *  *  Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved. MYNTRA
 *  *  PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.manager;

import com.myntra.commons.exception.ManagerException;
import com.myntra.commons.manager.BaseManager;
import com.myntra.mfp.entity.AnnualPlanEntity;
import com.myntra.mfp.entry.AnnualPlanEntry;
import com.myntra.mfp.entry.ViewPlanEntry;

import java.util.List;

/**
 * @author Dhiraj
 * @date 30/11/17
 */
public interface ViewAnnualPlanManager extends BaseManager<AnnualPlanEntry,AnnualPlanEntity>{
    List<AnnualPlanEntry> viewDetailedAnualPlan(ViewPlanEntry viewPlanEntry) throws ManagerException;

  //  AnnualPlanEntry saveAnnualPlan(AnnualPlanEntry annualPlanEntry);


}
