/*
 *
 *  *
 *  * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *  *
 *  * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.service;

import com.myntra.commons.service.BaseService;
import com.myntra.mfp.entity.ChannelEntity;
import com.myntra.mfp.entry.ChannelEntry;
import com.myntra.mfp.response.ChannelResponse;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

/**
 * @author Dhiraj
 * @date 04/12/17
 */
@Path("/channel")
public interface ChannelService extends BaseService<ChannelResponse,ChannelEntry,ChannelEntity> {

    @GET
    @Path("/getchannels")
    @Produces({"application/json","application/xml"})
    @Consumes({"application/json","application/xml"})
    ChannelResponse getAllChannels();
}
