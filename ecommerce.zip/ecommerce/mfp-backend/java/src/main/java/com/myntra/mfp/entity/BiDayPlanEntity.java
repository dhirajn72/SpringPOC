package com.myntra.mfp.entity;

import com.myntra.commons.entities.BaseEntity;

import javax.persistence.*;
import java.util.Date;

/**
 * @Author Dinesh
 * @date 30/11/17
 */

@Entity
@Table(name="bi_day_table")
@NamedQueries(value = {
        @NamedQuery(name = BiDayPlanEntity.GET_ID,
                query = "select bi from BiDayPlanEntity bi where bi.id = :id")
})

@NamedNativeQueries(value = {
        @NamedNativeQuery(name = BiDayPlanEntity.GET_BI_RECORDS,
                query = "SELECT * FROM bi_day_table", resultClass = SalesAnnualPlanEntity.class)
})

public class BiDayPlanEntity extends BaseEntity{
    public static final String GET_ID="GetId";

    public static final String GET_BI_RECORDS="getBiRecords";
    public static final String GET_MRP_PER_UNIT="Mrp_per_unit";


    @Column(name = "gmv")
    private Double gmv;

    @Column(name = "mrp_per_unit")
    private Double mrp_per_unit;

    @Column(name = "aisp")
    private Double aisp;

    @Column(name = "cf")
    private Double cf;

    @Column(name = "tax_recovery")
    private Double tax_recovery;

    @Column(name = "bm_contractual")
    private Double bm_contractual;

    @Column(name = "bm_type")
    private String bm_type;

    @Column(name = "vf_contractual")
    private Double vf_contractual;

    @Column(name = "royalty")
    private Double royalty;

    @Column(name = "tax")
    private Double tax;

    @Column(name = "mrp")
    private Double mrp;

    @Column(name = "mrp_ex_tax")
    private Double mrp_ex_tax;

    @Column(name = "ipp")
    private Double ipp;

    @Column(name = "bm_notional")
    private Double bm_notional;

    @Column(name = "cogs")
    private Double cogs;

    @Column(name = "gm_percent")
    private Double gm_percent;

    @Column(name = "forward_doh")
    private int forward_doh;

    @Column(name = "opening_inventory")
    private int opening_inventory;

    @Column(name = "units_sold")
    private int units_sold;

    @Column(name = "current_inventory")
    private int current_inventory;

    @Column(name = "new_styles_added")
    private int new_styles_added;

    @Column(name = "live_styles_month_end")
    private int live_styles_month_end;

    @Column(name = "last_modified_by")
    private String last_modified_by;

    @Column(name = "date_bi")
    private Date date_bi;

    @Column(name = "gmv_ratio")
    private Double gmv_ratio;


    @OneToOne
    @JoinColumn(name = "financial_year", referencedColumnName = "id")
    private FinancialYearEntity finalcialYearEntity;


    @OneToOne
    @JoinColumn(name = "channel", referencedColumnName = "id")
    private ChannelEntity channelEntity;


    @OneToOne
    @JoinColumn(name = "source", referencedColumnName = "id")
    private SourceEntity sourceEntity;


    @OneToOne
    @JoinColumn(name = "business_unit", referencedColumnName = "id")
    private BusinessUnitEntity businessUnitEntity;

    @OneToOne
    @JoinColumn(name = "brand_group", referencedColumnName = "id")
    private BrandGroupEntity brandGroupEntity;

    @OneToOne
    @JoinColumn(name = "brand", referencedColumnName = "id")
    private BrandEntity brandEntity;

    @OneToOne
    @JoinColumn(name = "master_category", referencedColumnName = "id")
    private MasterCategoryEntity masterCategoryEntity;

    @OneToOne
    @JoinColumn(name = "gender", referencedColumnName = "id")
    private GenderEntity genderEntity;

    @OneToOne
    @JoinColumn(name = "article", referencedColumnName = "id")
    private ArticleEntity articleEntity;

    @OneToOne
    @JoinColumn(name = "commercial_type", referencedColumnName = "id")
    private CommercialTypeEntity commercialTypeEntity;

    @OneToOne
    @JoinColumn(name = "price_point", referencedColumnName = "id")
    private PricePointEntity pricePointEntity;

    public BiDayPlanEntity() {
    }

    public BiDayPlanEntity(Long id, String createdBy, Date createdOn, Double gmv, Double mrp_per_unit, Double aisp, Double cf, Double tax_recovery, Double bm_contractual, String bm_type, Double vf_contractual, Double royalty, Double tax, Double mrp, Double mrp_ex_tax, Double ipp, Double bm_notional, Double cogs, Double gm_percent, int forward_doh, int opening_inventory, int units_sold, int current_inventory, int new_styles_added, int live_styles_month_end, String last_modified_by, Date date_bi, Double gmv_ratio, FinancialYearEntity finalcialYearEntity, ChannelEntity channelEntity, SourceEntity sourceEntity, BusinessUnitEntity businessUnitEntity, BrandGroupEntity brandGroupEntity, BrandEntity brandEntity, MasterCategoryEntity masterCategoryEntity, GenderEntity genderEntity, ArticleEntity articleEntity, CommercialTypeEntity commercialTypeEntity, PricePointEntity pricePointEntity) {
        super(id, createdBy, createdOn);
        this.gmv = gmv;
        this.mrp_per_unit = mrp_per_unit;
        this.aisp = aisp;
        this.cf = cf;
        this.tax_recovery = tax_recovery;
        this.bm_contractual = bm_contractual;
        this.bm_type = bm_type;
        this.vf_contractual = vf_contractual;
        this.royalty = royalty;
        this.tax = tax;
        this.mrp = mrp;
        this.mrp_ex_tax = mrp_ex_tax;
        this.ipp = ipp;
        this.bm_notional = bm_notional;
        this.cogs = cogs;
        this.gm_percent = gm_percent;
        this.forward_doh = forward_doh;
        this.opening_inventory = opening_inventory;
        this.units_sold = units_sold;
        this.current_inventory = current_inventory;
        this.new_styles_added = new_styles_added;
        this.live_styles_month_end = live_styles_month_end;
        this.last_modified_by = last_modified_by;
        this.date_bi = date_bi;
        this.gmv_ratio = gmv_ratio;
        this.finalcialYearEntity = finalcialYearEntity;
        this.channelEntity = channelEntity;
        this.sourceEntity = sourceEntity;
        this.businessUnitEntity = businessUnitEntity;
        this.brandGroupEntity = brandGroupEntity;
        this.brandEntity = brandEntity;
        this.masterCategoryEntity = masterCategoryEntity;
        this.genderEntity = genderEntity;
        this.articleEntity = articleEntity;
        this.commercialTypeEntity = commercialTypeEntity;
        this.pricePointEntity = pricePointEntity;
    }

    public Double getGmv() {
        return gmv;
    }

    public void setGmv(Double gmv) {
        this.gmv = gmv;
    }

    public Double getMrp_per_unit() {
        return mrp_per_unit;
    }

    public void setMrp_per_unit(Double mrp_per_unit) {
        this.mrp_per_unit = mrp_per_unit;
    }

    public Double getAisp() {
        return aisp;
    }

    public void setAisp(Double aisp) {
        this.aisp = aisp;
    }

    public Double getCf() {
        return cf;
    }

    public void setCf(Double cf) {
        this.cf = cf;
    }

    public Double getTax_recovery() {
        return tax_recovery;
    }

    public void setTax_recovery(Double tax_recovery) {
        this.tax_recovery = tax_recovery;
    }

    public Double getBm_contractual() {
        return bm_contractual;
    }

    public void setBm_contractual(Double bm_contractual) {
        this.bm_contractual = bm_contractual;
    }

    public String getBm_type() {
        return bm_type;
    }

    public void setBm_type(String bm_type) {
        this.bm_type = bm_type;
    }

    public Double getVf_contractual() {
        return vf_contractual;
    }

    public void setVf_contractual(Double vf_contractual) {
        this.vf_contractual = vf_contractual;
    }

    public Double getRoyalty() {
        return royalty;
    }

    public void setRoyalty(Double royalty) {
        this.royalty = royalty;
    }

    public Double getTax() {
        return tax;
    }

    public void setTax(Double tax) {
        this.tax = tax;
    }

    public Double getMrp() {
        return mrp;
    }

    public void setMrp(Double mrp) {
        this.mrp = mrp;
    }

    public Double getMrp_ex_tax() {
        return mrp_ex_tax;
    }

    public void setMrp_ex_tax(Double mrp_ex_tax) {
        this.mrp_ex_tax = mrp_ex_tax;
    }

    public Double getIpp() {
        return ipp;
    }

    public void setIpp(Double ipp) {
        this.ipp = ipp;
    }

    public Double getBm_notional() {
        return bm_notional;
    }

    public void setBm_notional(Double bm_notional) {
        this.bm_notional = bm_notional;
    }

    public Double getCogs() {
        return cogs;
    }

    public void setCogs(Double cogs) {
        this.cogs = cogs;
    }

    public Double getGm_percent() {
        return gm_percent;
    }

    public void setGm_percent(Double gm_percent) {
        this.gm_percent = gm_percent;
    }

    public int getForward_doh() {
        return forward_doh;
    }

    public void setForward_doh(int forward_doh) {
        this.forward_doh = forward_doh;
    }

    public int getOpening_inventory() {
        return opening_inventory;
    }

    public void setOpening_inventory(int opening_inventory) {
        this.opening_inventory = opening_inventory;
    }

    public int getUnits_sold() {
        return units_sold;
    }

    public void setUnits_sold(int units_sold) {
        this.units_sold = units_sold;
    }

    public int getCurrent_inventory() {
        return current_inventory;
    }

    public void setCurrent_inventory(int current_inventory) {
        this.current_inventory = current_inventory;
    }

    public int getNew_styles_added() {
        return new_styles_added;
    }

    public void setNew_styles_added(int new_styles_added) {
        this.new_styles_added = new_styles_added;
    }

    public int getLive_styles_month_end() {
        return live_styles_month_end;
    }

    public void setLive_styles_month_end(int live_styles_month_end) {
        this.live_styles_month_end = live_styles_month_end;
    }

    public String getLast_modified_by() {
        return last_modified_by;
    }

    public void setLast_modified_by(String last_modified_by) {
        this.last_modified_by = last_modified_by;
    }

    public Date getDate_ap() {
        return date_bi;
    }

    public void setDate_ap(Date date_ap) {
        this.date_bi = date_bi;
    }

    public FinancialYearEntity getFinalcialYearEntity() {
        return finalcialYearEntity;
    }

    public void setFinalcialYearEntity(FinancialYearEntity finalcialYearEntity) {
        this.finalcialYearEntity = finalcialYearEntity;
    }

    public ChannelEntity getChannelEntity() {
        return channelEntity;
    }

    public void setChannelEntity(ChannelEntity channelEntity) {
        this.channelEntity = channelEntity;
    }

    public SourceEntity getSourceEntity() {
        return sourceEntity;
    }

    public void setSourceEntity(SourceEntity sourceEntity) {
        this.sourceEntity = sourceEntity;
    }

    public BusinessUnitEntity getBusinessUnitEntity() {
        return businessUnitEntity;
    }

    public void setBusinessUnitEntity(BusinessUnitEntity businessUnitEntity) {
        this.businessUnitEntity = businessUnitEntity;
    }

    public BrandGroupEntity getBrandGroupEntity() {
        return brandGroupEntity;
    }

    public void setBrandGroupEntity(BrandGroupEntity brandGroupEntity) {
        this.brandGroupEntity = brandGroupEntity;
    }

    public BrandEntity getBrandEntity() {
        return brandEntity;
    }

    public void setBrandEntity(BrandEntity brandEntity) {
        this.brandEntity = brandEntity;
    }

    public MasterCategoryEntity getMasterCategoryEntity() {
        return masterCategoryEntity;
    }

    public void setMasterCategoryEntity(MasterCategoryEntity masterCategoryEntity) {
        this.masterCategoryEntity = masterCategoryEntity;
    }

    public GenderEntity getGenderEntity() {
        return genderEntity;
    }

    public void setGenderEntity(GenderEntity genderEntity) {
        this.genderEntity = genderEntity;
    }

    public ArticleEntity getArticleEntity() {
        return articleEntity;
    }

    public void setArticleEntity(ArticleEntity articleEntity) {
        this.articleEntity = articleEntity;
    }

    public CommercialTypeEntity getCommercialTypeEntity() {
        return commercialTypeEntity;
    }

    public void setCommercialTypeEntity(CommercialTypeEntity commercialTypeEntity) {
        this.commercialTypeEntity = commercialTypeEntity;
    }

    public PricePointEntity getPricePointEntity() {
        return pricePointEntity;
    }

    public void setPricePointEntity(PricePointEntity pricePointEntity) {
        this.pricePointEntity = pricePointEntity;
    }

    public Date getDate_bi() {
        return date_bi;
    }

    public void setDate_bi(Date date_bi) {
        this.date_bi = date_bi;
    }

    public Double getGmv_ratio() {
        return gmv_ratio;
    }

    public void setGmv_ratio(Double gmv_ratio) {
        this.gmv_ratio = gmv_ratio;
    }
}
