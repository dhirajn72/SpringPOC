/**
 *
 * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *
 * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 **/
package com.myntra.mfp.service.impl;

import com.myntra.mfp.service.OrderService;

/**
 * @author Dhiraj
 * @date 23/11/17
 */

public class OrderServiceImpl implements OrderService {


    @Override
    public String getHelloWorld() {
        return "Hello World !";
    }
}
