package com.myntra.mfp.service;

import com.myntra.mfp.entity.AnnualPlanModel;
import marvin.client.entry.UserViewEntry;

import javax.ws.rs.*;
import java.util.List;

@Path("/aggregate/")
public interface AggregationService {


    @POST
    @Path("getUserView")
    @Consumes({"application/json"})
    @Produces({"application/json"})
    public List<AnnualPlanModel> getUserView(UserViewEntry userViewEntry, @QueryParam("Page") Integer page, @QueryParam("PageLimit") Integer pageLimit);

}
