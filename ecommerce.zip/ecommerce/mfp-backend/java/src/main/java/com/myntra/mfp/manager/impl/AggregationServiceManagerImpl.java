package com.myntra.mfp.manager.impl;

import com.myntra.commons.exception.DaoException;
import com.myntra.commons.manager.impl.BaseManagerImpl;
import com.myntra.mfp.dao.AggregationDAO;
import com.myntra.mfp.entity.AnnualPlanEntity;
import com.myntra.mfp.entity.AnnualPlanModel;
import com.myntra.mfp.entity.MetricsModel;
import com.myntra.mfp.enums.AggregationSumParameters;
import com.myntra.mfp.enums.AggregationWeightedAvgParameters;
import com.myntra.mfp.enums.UserHirarchy;
import com.myntra.mfp.manager.AggregationServiceManager;
import marvin.client.entry.UserViewEntry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.*;

public class AggregationServiceManagerImpl extends BaseManagerImpl<UserViewEntry,AnnualPlanEntity> implements AggregationServiceManager{


    private static final Logger LOGGER = LoggerFactory.getLogger(AggregationServiceManagerImpl.class);

    private AggregationDAO aggregationDAO;

    public void setAggregationDAO(AggregationDAO aggregationDAO) {
        this.aggregationDAO = aggregationDAO;
    }



    @Override
    public List<AnnualPlanModel> getAggregationOnUserAxis(UserViewEntry userViewEntry, Integer page, Integer pageLimit) throws DaoException, SQLException {
        String[] userViewEntrys = userViewEntry.getUserView().split("-");
        String subQuery = "";
        String queryFormat="";
        String parentValue = null;
        String channel=null;

        for (String userView : userViewEntrys) {
            if (userView.equalsIgnoreCase(UserHirarchy.BUSINESS_UNIT.getLevelValue())) {
                subQuery = subQuery + "business_unit,";
                queryFormat = queryFormat + UserHirarchy.BUSINESS_UNIT.getLevelValue()+",";
                continue;
            }
            if (userView.equalsIgnoreCase(UserHirarchy.BRANDGROUP.getLevelValue())) {
                subQuery = subQuery + "brand_group,";
                queryFormat = queryFormat + UserHirarchy.BRANDGROUP.getLevelValue()+",";
                continue;
            }
            if (userView.equalsIgnoreCase(UserHirarchy.BRAND.getLevelValue())) {
                subQuery = subQuery + "brand,";
                queryFormat = queryFormat + UserHirarchy.BRAND.getLevelValue()+",";
                continue;
            }
            if (userView.equalsIgnoreCase(UserHirarchy.MASTER_CATEGORY.getLevelValue())) {
                subQuery = subQuery + "master_category,";
                queryFormat = queryFormat + UserHirarchy.MASTER_CATEGORY.getLevelValue()+",";
                continue;
            }
            if (userView.equalsIgnoreCase(UserHirarchy.ARTICLE.getLevelValue())) {
                subQuery = subQuery + "article,";
                queryFormat = queryFormat + UserHirarchy.ARTICLE.getLevelValue()+",";
                continue;
            }

            if (userView.equalsIgnoreCase(UserHirarchy.GENDER.getLevelValue())) {
                subQuery = subQuery + "gender,";
                queryFormat = queryFormat + UserHirarchy.GENDER.getLevelValue()+",";
                continue;
            }
        }

        if (userViewEntry.getParentValue() != null) {
            parentValue = userViewEntry.getParentValue();
        }
        if (userViewEntry.getChannel() != null) {
            channel = userViewEntry.getChannel();
        }
        LocalDate financialYearBiegin = LocalDate.now().plusYears(1).withMonth(4).withDayOfMonth(1);
        LocalDate financialYearEnd = financialYearBiegin.plusMonths(11).withDayOfMonth(1).minusDays(1);


        String userQuery = "SELECT "+subQuery.substring(0, subQuery.length() - 1)+" from mfp.annual_plan where business_unit=26 and date_ap " +
                            "between '"+financialYearBiegin+"' and '"+financialYearEnd+"' group by " + subQuery.substring(0, subQuery.length() - 1) ;

        LOGGER.info("query for user view " + userQuery);


        List<Object[]> result = this.dao.getEntityManager(true).createNativeQuery(userQuery)
                                .setFirstResult((page-1)*pageLimit)
                                .setMaxResults(pageLimit)
                                .getResultList();

        Map<String,String> queryMap=new LinkedHashMap<>();
        String q[] =queryFormat.substring(0, queryFormat.length() - 1).split(",");

        for(String s:q){
            queryMap.put(s,s);
        }

        List<AnnualPlanModel> annualPlanModelList = mapResultToResponseForSummation(result, queryMap);
        queryMap =new LinkedHashMap<>();
        for(AnnualPlanModel apr:annualPlanModelList){
            List<MetricsModel> metricsModelList = new ArrayList<>();
            String whereQuery= getWhereQuery(q,apr );
            LOGGER.info("Getting details for query where: "+whereQuery);
            for(int i= 0; i<12;i++){

                LocalDate monthBegin = LocalDate.now().plusYears(1).withMonth(4).plusMonths(i).withDayOfMonth(1);
                LocalDate monthEnd = monthBegin.plusMonths(1).withDayOfMonth(1).minusDays(1);
                LOGGER.info("getting data between months:  "+monthBegin+ " and "+ monthEnd);

                String query = "SELECT SUM(gmv) AS gmv, sum(mrp) AS mrp, sum(ipp) AS ipp, sum(cogs) as cogs, " +
                        "TRUNCATE((sum((mrp_per_unit*units_sold))/sum(units_sold)), 2) AS mrp_per_unit, " +
                        "TRUNCATE((sum(tax_recovery)/sum(mrp)),4) AS tax_recovery, " +
                        "TRUNCATE((SUM(bm_contractual)/sum(mrp_ex_tax)),2) AS bm_contractual " +
                        "FROM Annual_Plan where " + userViewEntry.getParent() + "=" + parentValue +
                        " and "+whereQuery+" date_ap between '"+monthBegin+"' AND '"+monthEnd+"'";

                LOGGER.info("query for aggregation view " + query);


                List<Object[]> viewResult = this.dao.getEntityManager(true).createNativeQuery(query).getResultList();
                //put sales plan metrics
                queryMap.put("gmv","gmv");
                queryMap.put("mrp","mrp");
                queryMap.put("ipp","ipp");
                queryMap.put("cogs","cogs");

                //put inventory metrics as well
                queryMap.put("mrp_per_unit","mrp_per_unit");
                queryMap.put("tax_recovery","tax_recovery");
                queryMap.put("bm_contractual","bm_contractual");
                MetricsModel metricsModel = new MetricsModel()  ;

                if(!viewResult.isEmpty() && viewResult.get(0)[0]!=null){
                        metricsModel = mapResultToResponseForUserView(viewResult, queryMap);
                        metricsModel.setMonth(monthBegin.getMonthValue());
                        metricsModel.setDataPresent(true);
                }else{
                    LOGGER.info("NoRecord Found for month "+ monthBegin.getMonth().toString());
                    metricsModel.setMonth(monthBegin.getMonthValue());
                    metricsModel.setDataPresent(false);

                }

                metricsModelList.add(metricsModel);
            }
            apr.setMetricsModel(metricsModelList);

        }
        return annualPlanModelList;
    }

    private String getWhereQuery(String[] q, AnnualPlanModel apr) {
        String whereQuery ="";
        for(String s:q){
            if(s.equalsIgnoreCase((UserHirarchy.BUSINESS_UNIT.getLevelValue()))){
                whereQuery= whereQuery + "business_unit="+apr.getBussinessUnit()+ " and ";
                continue;
            }
            if(s.equalsIgnoreCase((UserHirarchy.MASTER_CATEGORY.getLevelValue()))){
                whereQuery= whereQuery + "master_category="+apr.getMasterCategory()+ " and ";
                continue;
            }
            if(s.equalsIgnoreCase((UserHirarchy.BRANDGROUP.getLevelValue()))){
                whereQuery= whereQuery + "brand_group="+apr.getBrandGroup()+ " and ";
                continue;
            }
            if(s.equalsIgnoreCase((UserHirarchy.BRAND.getLevelValue()))){
                whereQuery= whereQuery + "brand="+apr.getBrand()+ " and ";
                continue;
            }
            if(s.equalsIgnoreCase((UserHirarchy.ARTICLE.getLevelValue()))){
                whereQuery= whereQuery + "article="+apr.getArticle()+ " and ";
                continue;
            }
            if(s.equalsIgnoreCase((UserHirarchy.GENDER.getLevelValue()))){
                whereQuery= whereQuery + "gender="+apr.getGender()+ " and ";
                continue;
            }
            if(s.equalsIgnoreCase((UserHirarchy.PRICE_POINT.getLevelValue()))){
                whereQuery= whereQuery + "price_point="+apr.getPricePoint()+ " and ";
                continue;
            }
        }
        return whereQuery;
    }


    private List<AnnualPlanModel> mapResultToResponseForSummation(List<Object[]> result,Map<String,String> queryMap ) {
        AnnualPlanModel aPR = new AnnualPlanModel();
        List<AnnualPlanModel> annualPlanModelList= new ArrayList<>();
        Map<String,String> queryMap1 = new LinkedHashMap<>();
        for(Object[] obj:result){
            if(queryMap1.size()>0){
                queryMap=queryMap1;
                queryMap1=new LinkedHashMap<>();
            }
            aPR = new AnnualPlanModel();
            for(Object ob:obj){
                Iterator it = queryMap.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry pair = (Map.Entry)it.next();
                    System.out.println(pair.getKey() + " = " + pair.getValue());
                    if(pair.getKey().toString().equalsIgnoreCase(UserHirarchy.BUSINESS_UNIT.getLevelValue())){
                        LOGGER.info(">>>> looking for business_unit");
                        aPR.setBussinessUnit((Integer)ob);
                        queryMap1.put(pair.getKey().toString(),pair.getValue().toString());
                    }
                    if(pair.getKey().toString().equalsIgnoreCase(UserHirarchy.BRANDGROUP.getLevelValue())){
                        LOGGER.info(">>>> looking for BRANDGROUP");
                        aPR.setBrandGroup((Integer)ob);
                        queryMap1.put(pair.getKey().toString(),pair.getValue().toString());
                    }
                    if(pair.getKey().toString().equalsIgnoreCase(UserHirarchy.BRAND.getLevelValue())){
                        LOGGER.info(">>>> looking for BRAND");
                        aPR.setBrand((Integer)ob);
                        queryMap1.put(pair.getKey().toString(),pair.getValue().toString());
                    }
                    if(pair.getKey().toString().equalsIgnoreCase(UserHirarchy.ARTICLE.getLevelValue())){
                        LOGGER.info(">>>> loking for ARTICLE");
                        aPR.setArticle((Integer)ob);
                        queryMap1.put(pair.getKey().toString(),pair.getValue().toString());
                    }
                    if(pair.getKey().toString().equalsIgnoreCase(UserHirarchy.GENDER.getLevelValue())){
                        LOGGER.info(">>>> loking for GENDER");
                        aPR.setGender((Integer)ob);
                        queryMap1.put(pair.getKey().toString(),pair.getValue().toString());
                    }
                    if(pair.getKey().toString().equalsIgnoreCase(UserHirarchy.MASTER_CATEGORY.getLevelValue())){
                        LOGGER.info(">>>> loking for MASTER_CATEGORY");
                        aPR.setMasterCategory((Integer)ob);
                        queryMap1.put(pair.getKey().toString(),pair.getValue().toString());
                    }

                    it.remove();
                    break;
                }

            }
            annualPlanModelList.add(aPR);
        }
        return annualPlanModelList;
    }

    private MetricsModel mapResultToResponseForUserView(List<Object[]> result,Map<String,String> queryMap ) {
        MetricsModel metricsModel = new MetricsModel();
        Map<String,String> queryMap1 = new LinkedHashMap<>();
        for(Object[] obj:result){
            if(queryMap1.size()>0){
                queryMap=queryMap1;
                queryMap1=new LinkedHashMap<>();
            }
            for(Object ob:obj){
                Iterator it = queryMap.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry pair = (Map.Entry)it.next();
                    System.out.println(pair.getKey() + " = " + pair.getValue());
                    if(pair.getKey().toString().equalsIgnoreCase(AggregationSumParameters.GMV.getLevelValue())){
                        LOGGER.info(">>>> loking for GMV");
                        metricsModel.setGmv(((BigDecimal) ob).doubleValue());
                        queryMap1.put(pair.getKey().toString(),pair.getValue().toString());
                    }
                    if(pair.getKey().toString().equalsIgnoreCase(AggregationSumParameters.MRP.getLevelValue())){
                        LOGGER.info(">>>> loking for MRP");
                        metricsModel.setMrp(((BigDecimal) ob).doubleValue());
                        queryMap1.put(pair.getKey().toString(),pair.getValue().toString());
                    }
                    if(pair.getKey().toString().equalsIgnoreCase(AggregationSumParameters.IPP.getLevelValue())){
                        LOGGER.info(">>>> loking for IPP");
                        metricsModel.setIpp(((BigDecimal) ob).doubleValue());
                        queryMap1.put(pair.getKey().toString(),pair.getValue().toString());
                    }
                    if(pair.getKey().toString().equalsIgnoreCase(AggregationSumParameters.COGS.getLevelValue())){
                        LOGGER.info(">>>> loking for COGS");
                        metricsModel.setCogs(((BigDecimal) ob).doubleValue());
                        queryMap1.put(pair.getKey().toString(),pair.getValue().toString());
                    }
                    if(pair.getKey().toString().equalsIgnoreCase(AggregationWeightedAvgParameters.BM_CONTRACTUAL.getLevelValue())){
                        LOGGER.info(">>>> loking for BM_CONTRACTUAL");
                        metricsModel.setBmContractual(((BigDecimal) ob).doubleValue());
                        queryMap1.put(pair.getKey().toString(),pair.getValue().toString());
                    }
                    if(pair.getKey().toString().equalsIgnoreCase(AggregationWeightedAvgParameters.TAX_RECOVERY.getLevelValue())){
                        LOGGER.info(">>>> loking for TAX_RECOVERY");
                        metricsModel.setTaxRecovery(((BigDecimal) ob).doubleValue());
                        queryMap1.put(pair.getKey().toString(),pair.getValue().toString());
                    }
                    if(pair.getKey().toString().equalsIgnoreCase(AggregationWeightedAvgParameters.MRP_PER_UNIT.getLevelValue())){
                        LOGGER.info(">>>> loking for MRP_PER_UNIT");
                        metricsModel.setMrpPerUnit(((BigDecimal) ob).doubleValue());
                        queryMap1.put(pair.getKey().toString(),pair.getValue().toString());
                    }
                    it.remove();
                    break;
                }

            }
        }
        return metricsModel;
    }


}
