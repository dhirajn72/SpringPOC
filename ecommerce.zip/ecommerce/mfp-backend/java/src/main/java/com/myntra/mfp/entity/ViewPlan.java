/**
 *
 * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *
 * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 **/
package com.myntra.mfp.entity;

import com.myntra.commons.entities.BaseEntity;


import javax.persistence.*;
import java.util.Date;


/**
 * @author Dhiraj
 * @date 24/11/17
 */

@Entity
@Table(name = "mfp_annual_view_plan")
@NamedQueries(value = {
        @NamedQuery(name = ViewPlan.FIND_ALL_ANNUAL_PLANS,query = "select vp from ViewPlan vp order by vp.financialYearEntity.id desc "),
        @NamedQuery(name = ViewPlan.FIND_ALL_ANNUAL_PLANS_FOR_YEAR_AND_CHANNEL,query = "select vp from ViewPlan vp where vp.financialYearEntity.id = :financialYearId and vp.channelsEntity.id = :channelsId"),
        @NamedQuery(name = ViewPlan.FIND_ALL_ANNUAL_PLANS_FOR_YEAR,query = "select vp from ViewPlan vp where vp.financialYearEntity.id = :financialYearId"),
        @NamedQuery(name = ViewPlan.FIND_ALL_ANNUAL_PLANS_FOR_CHANNEL,query = "select vp from ViewPlan vp where vp.channelsEntity.id = :channelsId")
})
public class ViewPlan extends BaseEntity {

    public static final String FIND_ALL_ANNUAL_PLANS = "FindAllAnnualPlans";
    public static final String FIND_ALL_ANNUAL_PLANS_FOR_YEAR_AND_CHANNEL = "FindAllAnnualPlansForYearAndChannel";
    public static final String FIND_ALL_ANNUAL_PLANS_FOR_YEAR = "FindAllAnnualPlansForYear";
    public static final String FIND_ALL_ANNUAL_PLANS_FOR_CHANNEL = "FindAllAnnualPlansForChannel";

    @Column(name = "approved_by")
    private String approved_by;

    @Column(name = "last_modified_by")
    private String last_modified_by;


    @OneToOne
    @JoinColumn(name = "financial_year_id", referencedColumnName = "id")
    private FinancialYearEntity financialYearEntity;


    @OneToOne
    @JoinColumn(name = "channel_id", referencedColumnName = "id")
    private ChannelEntity channelsEntity;

    @OneToOne
    @JoinColumn(name = "status_id", referencedColumnName = "id")
    private PlanStatusEntity statusEntity;


    public ViewPlan() {
    }

    public ViewPlan(Long id, String createdBy, Date createdOn, String approved_by, String last_modified_by, FinancialYearEntity financialYearEntity, ChannelEntity channelsEntity, PlanStatusEntity statusEntity) {
        super(id, createdBy, createdOn);
        this.approved_by = approved_by;
        this.last_modified_by = last_modified_by;
        this.financialYearEntity = financialYearEntity;
        this.channelsEntity = channelsEntity;
        this.statusEntity = statusEntity;
    }

    public String getApproved_by() {
        return approved_by;
    }

    public void setApproved_by(String approved_by) {
        this.approved_by = approved_by;
    }

    public String getLast_modified_by() {
        return last_modified_by;
    }

    public void setLast_modified_by(String last_modified_by) {
        this.last_modified_by = last_modified_by;
    }

    public FinancialYearEntity getFinancialYearEntity() {
        return financialYearEntity;
    }

    public void setFinancialYearEntity(FinancialYearEntity financialYearEntity) {
        this.financialYearEntity = financialYearEntity;
    }

    public ChannelEntity getChannelsEntity() {
        return channelsEntity;
    }

    public void setChannelsEntity(ChannelEntity channelsEntity) {
        this.channelsEntity = channelsEntity;
    }

    public PlanStatusEntity getStatusEntity() {
        return statusEntity;
    }

    public void setStatusEntity(PlanStatusEntity statusEntity) {
        this.statusEntity = statusEntity;
    }
}
