/**
 *
 * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *
 * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 **/


package com.myntra.mfp.entity;

import com.myntra.commons.entities.BaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;

/**
 * @author Dhiraj
 * @date 29/11/17
 */

@Entity
@Table(name ="article_mstr" )
public class ArticleEntity extends BaseEntity {

    @Column(name = "article_name")
    private String article_name;


    @Column(name = "last_modified_by")
    private String last_modified_by;

    public ArticleEntity() {
    }

    public ArticleEntity(Long id, String createdBy, Date createdOn, String article_name, String last_modified_by) {
        super(id, createdBy, createdOn);
        this.article_name = article_name;
        this.last_modified_by = last_modified_by;
    }

    public String getArticle_name() {
        return article_name;
    }

    public void setArticle_name(String article_name) {
        this.article_name = article_name;
    }

    public String getLast_modified_by() {
        return last_modified_by;
    }

    public void setLast_modified_by(String last_modified_by) {
        this.last_modified_by = last_modified_by;
    }
}
