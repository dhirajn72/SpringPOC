/*
 *
 *  *
 *  * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *  *
 *  * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.manager;

import com.myntra.commons.exception.ManagerException;
import com.myntra.commons.manager.BaseManager;
import com.myntra.mfp.entity.FinancialYearEntity;
import com.myntra.mfp.entry.FinalcialYearEntry;

import java.util.List;

/**
 * @author Dhiraj
 * @date 04/12/17
 */
public interface FinancialYearManager extends BaseManager<FinalcialYearEntry,FinancialYearEntity>{

    List<FinalcialYearEntry> getAllYears() throws ManagerException;

}
