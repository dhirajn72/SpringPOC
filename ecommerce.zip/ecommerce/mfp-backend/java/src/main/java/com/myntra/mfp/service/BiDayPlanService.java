package com.myntra.mfp.service;
import com.myntra.commons.service.BaseService;
import com.myntra.mfp.entity.BiDayPlanEntity;
import com.myntra.mfp.entry.BiDayPlanEntry;
import com.myntra.mfp.response.BiDayPlanResponse;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

/**
 * @Author-Dinesh
 * @Date-30-11-2017
 */


@Path("/annual_plan")
public interface BiDayPlanService extends BaseService<BiDayPlanResponse, BiDayPlanEntry, BiDayPlanEntity>  {


    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("{AOPTarget}")
    public Double createAnnualPlan(@PathParam("AOPTarget") Double AOPTarget);


    @GET
    @Produces("text/plain")
    @Path("/helloworld")
    public String getHello();
}


