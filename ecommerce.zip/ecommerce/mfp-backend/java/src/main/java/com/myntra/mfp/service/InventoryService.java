package com.myntra.mfp.service;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Path("/inventory/")
public interface InventoryService {

        @GET
        @Produces("text/plain")
        @Path("calculate")
        public String getInventoryCalculations();
}
