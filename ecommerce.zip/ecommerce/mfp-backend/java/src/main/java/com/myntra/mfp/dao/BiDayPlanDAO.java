package com.myntra.mfp.dao;

import com.myntra.commons.dao.BaseDAO;
import com.myntra.mfp.entity.BiDayPlanEntity;

import java.util.List;

/**
 * @Author-Dinesh
 * @Date-30-11-2017
 */


public interface BiDayPlanDAO extends BaseDAO<BiDayPlanEntity> {


}
