/*
 *
 *  *  Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved. MYNTRA
 *  *  PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.service.impl;

import com.myntra.commons.codes.StatusResponse;
import com.myntra.commons.exception.ManagerException;
import com.myntra.commons.service.impl.BaseServiceImpl;
import com.myntra.mfp.code.MfpErrorCode;
import com.myntra.mfp.code.MfpSuccessCode;
import com.myntra.mfp.entity.AnnualPlanEntity;
import com.myntra.mfp.entry.AnnualPlanEntry;
import com.myntra.mfp.entry.ViewPlanEntry;
import com.myntra.mfp.manager.ViewAnnualPlanManager;
import com.myntra.mfp.response.ViewAnualPlanResponse;
import com.myntra.mfp.service.ViewAnnualPlanService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Dhiraj
 * @date 30/11/17
 */
public class ViewAnnualPlanServiceImpl extends BaseServiceImpl<ViewAnualPlanResponse, AnnualPlanEntry, AnnualPlanEntity> implements ViewAnnualPlanService{

    private static final Logger LOGGER = LoggerFactory.getLogger(ViewAnnualPlanServiceImpl.class.getName());

    public ViewAnnualPlanServiceImpl() {
        super(MfpSuccessCode.SUCCESS, MfpSuccessCode.SUCCESS, MfpSuccessCode.SUCCESS, MfpErrorCode.RECORD_NOT_FOUND);
    }

    @Override
    protected ViewAnualPlanResponse createResponse(List<AnnualPlanEntry> entries) {
        return null;
    }

    @Override
    public ViewAnualPlanResponse viewDetailedAnualPlan(ViewPlanEntry viewPlanEntry) {
        ViewAnualPlanResponse viewAnualPlanResponse = new ViewAnualPlanResponse();
        try {
            List<AnnualPlanEntry> viewPlanEntries = ((ViewAnnualPlanManager) manager).viewDetailedAnualPlan(viewPlanEntry);
            viewAnualPlanResponse.setData(viewPlanEntries);
            if (viewPlanEntries.isEmpty()) {
                viewAnualPlanResponse.setStatus(new StatusResponse(MfpErrorCode.RECORDS_NOT_FOUND, StatusResponse.Type.SUCCESS, viewPlanEntries.size()));
                return viewAnualPlanResponse;
            }
            viewAnualPlanResponse.setStatus(new StatusResponse(MfpSuccessCode.SUCCESS, StatusResponse.Type.SUCCESS, viewPlanEntries.size()));
        } catch (ManagerException e) {
            LOGGER.error("Error in view detailed anual plan");
            viewAnualPlanResponse.setStatus(e.getStatusResponse());

        }
        return viewAnualPlanResponse;
    }

}
