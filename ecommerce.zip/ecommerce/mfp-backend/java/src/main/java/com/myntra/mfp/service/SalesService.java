package com.myntra.mfp.service;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;


/**
 * @Author-Dinesh
 * @Date-4-12-2017
 */

@Path("/sales/")
public interface SalesService {

    @GET
    @Produces("text/plain")
    @Path("calculate")
    public String getSalesCalculations();
}
