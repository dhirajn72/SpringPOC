/*
 *
 *  *  Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved. MYNTRA
 *  *  PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.dao.impl;

import com.myntra.commons.dao.impl.BaseDAOImpl;
import com.myntra.mfp.dao.AnnualPlanDao;
import com.myntra.mfp.entity.*;
import com.myntra.mfp.entry.ViewPlanEntry;

import javax.persistence.Query;
import javax.transaction.Transactional;
import java.util.Date;
import java.util.List;


/**
 * @author Dhiraj
 * @date 30/11/17
 */
public class AnnualPlanDaoImpl extends BaseDAOImpl<AnnualPlanEntity> implements AnnualPlanDao {

    @Override
    public List<AnnualPlanEntity> viewDetailedAnualPlan(ViewPlanEntry viewPlanEntry) {
        Query query = this.getEntityManager(false).createNamedQuery(AnnualPlanEntity.GET_ANUAL_PLAN);
        query.setParameter("finalcialYearEntity", viewPlanEntry.getFinancialYearEntity().getId());
        // List<AnnualPlanEntity> planEntities=query.getResultList();
        //return  planEntities;


       AnnualPlanEntity ap = new AnnualPlanEntity(99l, viewPlanEntry.getCreatedBy(), viewPlanEntry.getCreatedOn(), 9999.98, 2345.12, 1234.234, 123.123, 123.234, 123.234, "Gross+Taxes", 234.345, 3456.456, 345.345, 2345.2345, 234.234, 2345.2345, 234.2345, 234.234, 12345.34, 234, 2345, 2345, 2345, 234, 2345, "dhiraj", viewPlanEntry.getCreatedOn(),
                getFinancialYearEntity(), getChannelEntity(), getSourceEntity(), getBusinessUnitEntity(), getBrandGroupEntity(), getBrandEntity(), getMasterCategoryEntity(), getGenderEntity(), getArticleEntity(), getCommercialTypeEntity(), getPricePointEntity());

        this.getEntityManager(false).merge(getFinancialYearEntity());
        this.getEntityManager(false).merge(getChannelEntity());
        this.getEntityManager(false).merge(getSourceEntity());
        this.getEntityManager(false).merge(getBusinessUnitEntity());
        this.getEntityManager(false).merge(getBrandGroupEntity());
        this.getEntityManager(false).merge(getBrandEntity());
        this.getEntityManager(false).merge(getMasterCategoryEntity());
        this.getEntityManager(false).merge(getGenderEntity());
        this.getEntityManager(false).merge(getArticleEntity());
        this.getEntityManager(false).merge(getCommercialTypeEntity());
        this.getEntityManager(false).merge(getPricePointEntity());


        this.getEntityManager(false).merge(ap);
        System.out.println("AnnualPlanEntity has been saved !");


        //List<AnnualPlanEntity> planEntities=query.getResultList();

        return query.getResultList();
    }
    private FinancialYearEntity getFinancialYearEntity(){
        return new FinancialYearEntity(11l, "dhiraj", new Date(), "march", "dhiraj");
    }
    private ChannelEntity getChannelEntity(){
        return new ChannelEntity(11l, "dhiraj", new Date(), "Myntra", "dhiraj");
    }
    private SourceEntity getSourceEntity(){
        return new SourceEntity(11l, "dhiraj", new Date(), "MMB", "dhiraj");
    }
    private BusinessUnitEntity getBusinessUnitEntity(){
        return new BusinessUnitEntity(27l, "dhiraj", new Date(), "Sports", "dhiraj");
    }
    private BrandGroupEntity getBrandGroupEntity(){
        return new BrandGroupEntity(1005l, "dhiraj", new Date(), "18+", "dhiraj");
    }
    private BrandEntity getBrandEntity(){
        return new BrandEntity(1001l, "dhiraj", new Date(), "Nike", "dhiraj");
    }
    private MasterCategoryEntity getMasterCategoryEntity(){
        return new MasterCategoryEntity(11l, "dhiraj", new Date(), "SOR", "dhiraj");
    }
    private GenderEntity getGenderEntity(){
        return new GenderEntity(11l, "dhiraj", new Date(), "Male", "dhiraj");
    }
    private ArticleEntity getArticleEntity(){
        return new ArticleEntity(491l, "dhiraj", new Date(), "Backpacks", "dhiraj");
    }
    private CommercialTypeEntity getCommercialTypeEntity(){
        return new CommercialTypeEntity(11l, "dhiraj", new Date(), "SOR", "dhiraj");
    }
    private PricePointEntity getPricePointEntity(){
        return new PricePointEntity(14l, "dhiraj", new Date(), "101-499", "dhiraj");
    }

}
