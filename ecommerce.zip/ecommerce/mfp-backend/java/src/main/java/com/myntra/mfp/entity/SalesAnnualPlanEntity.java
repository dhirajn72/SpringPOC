package com.myntra.mfp.entity;

import com.myntra.commons.entities.BaseEntity;

import javax.persistence.*;

/**
 * @Author-Dinesh
 * @Date-30-11-2017
 */

@Entity
@Table(name = "annual_plan")
@NamedQueries(value = {
        @NamedQuery(name = SalesAnnualPlanEntity.Get_ID_FOR_AP,
                query = "select ap from SalesAnnualPlanEntity ap where ap.id = :id")
})

public class SalesAnnualPlanEntity extends BaseEntity {
    public static final String Get_ID_FOR_AP = "GetAnualPlanId";


    @Column(name = "gmv")
    private Double gmv;

    @Column(name = "mrp_per_unit")
    private Double mrp_per_unit;

    @Column(name = "aisp")
    private Double aisp;

    @Column(name = "cf")
    private Double cf;

    @Column(name = "tax_recovery")
    private Double tax_recovery;

    @Column(name = "bm_contractual")
    private Double bm_contractual;

    @Column(name = "bm_type")
    private String bm_type;

    @Column(name = "vf_contractual")
    private Double vf_contractual;

    @Column(name = "royalty")
    private Double royalty;

    @Column(name = "tax")
    private Double tax;

    @Column(name = "mrp")
    private Double mrp;

    @Column(name = "mrp_ex_tax")
    private Double mrp_ex_tax;

    @Column(name = "ipp")
    private Double ipp;

    @Column(name = "bm_notional")
    private Double bm_notional;

    @Column(name = "cogs")
    private Double cogs;

    @Column(name = "gm_percent")
    private Double gm_percent;

    @Column(name = "forward_doh")
    private int forward_doh;

    @Column(name = "opening_inventory")
    private int opening_inventory;

    @Column(name = "units_sold")
    private int units_sold;

    @Column(name = "current_inventory")
    private int current_inventory;

    @Column(name = "new_styles_added")
    private int new_styles_added;

    @Column(name = "live_styles_month_end")
    private int live_styles_month_end;

    @Column(name = "last_modified_by")
    private String last_modified_by;

   /* @Column(name = "date_ap")
    private Date date_ap;*/

    @Column(name = "financial_year")
    private int finalcialYearEntity;


    @Column(name = "channel")
    private int channelEntity;


    @Column(name = "source")
    private int sourceEntity;


    @Column(name = "business_unit")
    private int businessUnitEntity;


    @Column(name = "brand_group")
    private int brandGroupEntity;


    @Column(name = "brand")
    private int brandEntity;


    @Column(name = "master_category")
    private int masterCategoryEntity;


    @Column(name = "gender")
    private int genderEntity;


    @Column(name = "article")
    private int articleEntity;


    @Column(name = "commercial_type")
    private int commercialTypeEntity;


    @Column(name = "price_point")
    private int pricePointEntity;


    public Double getGmv() {
        return gmv;
    }

    public void setGmv(Double gmv) {
        this.gmv = gmv;
    }

    public Double getMrp_per_unit() {
        return mrp_per_unit;
    }

    public void setMrp_per_unit(Double mrp_per_unit) {
        this.mrp_per_unit = mrp_per_unit;
    }

    public Double getAisp() {
        return aisp;
    }

    public void setAisp(Double aisp) {
        this.aisp = aisp;
    }

    public Double getCf() {
        return cf;
    }

    public void setCf(Double cf) {
        this.cf = cf;
    }

    public Double getTax_recovery() {
        return tax_recovery;
    }

    public void setTax_recovery(Double tax_recovery) {
        this.tax_recovery = tax_recovery;
    }

    public Double getBm_contractual() {
        return bm_contractual;
    }

    public void setBm_contractual(Double bm_contractual) {
        this.bm_contractual = bm_contractual;
    }

    public String getBm_type() {
        return bm_type;
    }

    public void setBm_type(String bm_type) {
        this.bm_type = bm_type;
    }

    public Double getVf_contractual() {
        return vf_contractual;
    }

    public void setVf_contractual(Double vf_contractual) {
        this.vf_contractual = vf_contractual;
    }

    public Double getRoyalty() {
        return royalty;
    }

    public void setRoyalty(Double royalty) {
        this.royalty = royalty;
    }

    public Double getTax() {
        return tax;
    }

    public void setTax(Double tax) {
        this.tax = tax;
    }

    public Double getMrp() {
        return mrp;
    }

    public void setMrp(Double mrp) {
        this.mrp = mrp;
    }

    public Double getMrp_ex_tax() {
        return mrp_ex_tax;
    }

    public void setMrp_ex_tax(Double mrp_ex_tax) {
        this.mrp_ex_tax = mrp_ex_tax;
    }

    public Double getIpp() {
        return ipp;
    }

    public void setIpp(Double ipp) {
        this.ipp = ipp;
    }

    public Double getBm_notional() {
        return bm_notional;
    }

    public void setBm_notional(Double bm_notional) {
        this.bm_notional = bm_notional;
    }

    public Double getCogs() {
        return cogs;
    }

    public void setCogs(Double cogs) {
        this.cogs = cogs;
    }

    public Double getGm_percent() {
        return gm_percent;
    }

    public void setGm_percent(Double gm_percent) {
        this.gm_percent = gm_percent;
    }

    public int getForward_doh() {
        return forward_doh;
    }

    public void setForward_doh(int forward_doh) {
        this.forward_doh = forward_doh;
    }

    public int getOpening_inventory() {
        return opening_inventory;
    }

    public void setOpening_inventory(int opening_inventory) {
        this.opening_inventory = opening_inventory;
    }

    public int getUnits_sold() {
        return units_sold;
    }

    public void setUnits_sold(int units_sold) {
        this.units_sold = units_sold;
    }

    public int getCurrent_inventory() {
        return current_inventory;
    }

    public void setCurrent_inventory(int current_inventory) {
        this.current_inventory = current_inventory;
    }

    public int getNew_styles_added() {
        return new_styles_added;
    }

    public void setNew_styles_added(int new_styles_added) {
        this.new_styles_added = new_styles_added;
    }

    public int getLive_styles_month_end() {
        return live_styles_month_end;
    }

    public void setLive_styles_month_end(int live_styles_month_end) {
        this.live_styles_month_end = live_styles_month_end;
    }

    public String getLast_modified_by() {
        return last_modified_by;
    }

    public void setLast_modified_by(String last_modified_by) {
        this.last_modified_by = last_modified_by;
    }

    public int getFinalcialYearEntity() {
        return finalcialYearEntity;
    }

    public void setFinalcialYearEntity(int finalcialYearEntity) {
        this.finalcialYearEntity = finalcialYearEntity;
    }

    public int getChannelEntity() {
        return channelEntity;
    }

    public void setChannelEntity(int channelEntity) {
        this.channelEntity = channelEntity;
    }

    public int getSourceEntity() {
        return sourceEntity;
    }

    public void setSourceEntity(int sourceEntity) {
        this.sourceEntity = sourceEntity;
    }

    public int getBusinessUnitEntity() {
        return businessUnitEntity;
    }

    public void setBusinessUnitEntity(int businessUnitEntity) {
        this.businessUnitEntity = businessUnitEntity;
    }

    public int getBrandGroupEntity() {
        return brandGroupEntity;
    }

    public void setBrandGroupEntity(int brandGroupEntity) {
        this.brandGroupEntity = brandGroupEntity;
    }

    public int getBrandEntity() {
        return brandEntity;
    }

    public void setBrandEntity(int brandEntity) {
        this.brandEntity = brandEntity;
    }

    public int getMasterCategoryEntity() {
        return masterCategoryEntity;
    }

    public void setMasterCategoryEntity(int masterCategoryEntity) {
        this.masterCategoryEntity = masterCategoryEntity;
    }

    public int getGenderEntity() {
        return genderEntity;
    }

    public void setGenderEntity(int genderEntity) {
        this.genderEntity = genderEntity;
    }

    public int getArticleEntity() {
        return articleEntity;
    }

    public void setArticleEntity(int articleEntity) {
        this.articleEntity = articleEntity;
    }

    public int getCommercialTypeEntity() {
        return commercialTypeEntity;
    }

    public void setCommercialTypeEntity(int commercialTypeEntity) {
        this.commercialTypeEntity = commercialTypeEntity;
    }

    public int getPricePointEntity() {
        return pricePointEntity;
    }

    public void setPricePointEntity(int pricePointEntity) {
        this.pricePointEntity = pricePointEntity;
    }

   /*public Date getDate_ap() {
        return date_ap;
    }

    public void setDate_ap(Date date_ap) {
        this.date_ap = date_ap;
    }*/
}



