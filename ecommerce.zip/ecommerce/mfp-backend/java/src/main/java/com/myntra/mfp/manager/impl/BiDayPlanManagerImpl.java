package com.myntra.mfp.manager.impl;
import com.myntra.commons.manager.impl.BaseManagerImpl;
import com.myntra.mfp.dao.BiDayPlanDAO;
import com.myntra.mfp.entity.SalesAnnualPlanEntity;
import com.myntra.mfp.entity.BiDayPlanEntity;
import com.myntra.mfp.entry.BiDayPlanEntry;
import com.myntra.mfp.manager.BiDayPlanManager;
import com.myntra.mfp.utils.SalesFormulae;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.util.List;

/**
 * @Author-Dinesh
 * @Date-30-11-2017
 */

public class BiDayPlanManagerImpl extends BaseManagerImpl<BiDayPlanEntry, BiDayPlanEntity> implements BiDayPlanManager {

    public static final Logger LOGGER = LoggerFactory.getLogger(BiDayPlanManagerImpl.class);

    private BiDayPlanDAO biDayPlanDAO;

    private SalesFormulae salesformulae;

    public void setSalesformulae(SalesFormulae salesformulae) {
        this.salesformulae = salesformulae;
    }

    public void setBiDayPlanDAO(BiDayPlanDAO biDayPlanDAO) {
        this.biDayPlanDAO = biDayPlanDAO;
    }


   /* public Double getMrpPerUnitSum()
    {
        List<Object> totalMrp_Per_Unit = this.biDayPlanDAO.getEntityManager(true).createNamedQuery(BiDayPlanEntity.GET_MRP_PER_UNIT).getResultList();
        totalMrp_Per_Unit.size();
        return 0.0;
    }*/


    @Override
    public Double getTotalSumOfGmvOfHistoricData() {

        //getting Sum of GMV from Bi_day_Table
        List<Object> totalGmv = this.biDayPlanDAO.getEntityManager(true).createNativeQuery("SELECT SUM(gmv) AS gmv from bi_day_table").getResultList();
        double _totalGmv = ((BigDecimal) totalGmv.get(0)).doubleValue();
        LOGGER.info("Total Sum of gmv = " + totalGmv);
        return _totalGmv;
    }

    @Override
    public List<SalesAnnualPlanEntity> getAnnualPlanWithUpdatedMetrics(Double AOPTarget, Double _totalGmv, Integer startIndex, Integer maxResult) {

        List<SalesAnnualPlanEntity> entityList = null;

        //getting records from bi_day_Table and alias(result class = SalesAnnualPlanEntity) from BiDayEntity to AnnualPlanDayEntity
        entityList = this.biDayPlanDAO.getEntityManager(true).createNamedQuery(BiDayPlanEntity.GET_BI_RECORDS).setFirstResult(startIndex).setMaxResults(maxResult).getResultList();

        LOGGER.info("Total Records = " + entityList.size());

        for (SalesAnnualPlanEntity annualPlanEntity : entityList) {
            SalesAnnualPlanEntity annualPlanEntityHistoric = annualPlanEntity;

            //getting gmv
            double gmvBI = annualPlanEntity.getGmv();

            //calculating ratio
            double gmvAP = (gmvBI / _totalGmv) * AOPTarget;
            LOGGER.info("New gmv for record " + annualPlanEntity.getId() + " is : " + gmvAP);
            annualPlanEntity.setGmv(gmvAP);

            //rules matrics applied for calculations
            annualPlanEntity.setAisp(salesformulae.calculateAisp(gmvBI, annualPlanEntityHistoric.getUnits_sold()));
            annualPlanEntity.setBm_notional(salesformulae.calculateBmPercentNotionalOR(annualPlanEntityHistoric.getIpp(),
                    annualPlanEntityHistoric.getMrp_ex_tax()));
            //annualPlanEntity.setMrp(formulae.calculateMrp(gmvBI,annualPlanEntityHistoric.getTax_recovery(),annualPlanEntityHistoric.getTax_Revenue_percentage(),annualPlanEntityHistoric.getTax_recovery(),annualPlanEntityHistoric.getCf(),annualPlanEntityHistoric.getVf_contractual()));
            annualPlanEntity.setCogs(salesformulae.calculateCogs(annualPlanEntityHistoric.getIpp(),
                    annualPlanEntityHistoric.getVf_contractual()));
            annualPlanEntity.setGm_percent(salesformulae.calculateGmPercent(annualPlanEntityHistoric.getCogs(),
                    annualPlanEntityHistoric.getTax(), gmvBI));
            annualPlanEntity.setUnits_sold(salesformulae.calculateUnitsSold(Double.valueOf(annualPlanEntityHistoric.getMrp()),
                    Double.valueOf(annualPlanEntityHistoric.getUnits_sold())).intValue());
            annualPlanEntity.setMrp_ex_tax(salesformulae.calculateMrpExTaxOR(annualPlanEntityHistoric.getMrp(),
                    annualPlanEntityHistoric.getTax()));
            annualPlanEntity.setIpp(salesformulae.calculateIppOR(annualPlanEntityHistoric.getMrp_ex_tax(),
                    annualPlanEntityHistoric.getBm_contractual(), annualPlanEntityHistoric.getMrp()));
            //annualPlanEntity.setTax(formulae.calculateTaxOR(gmvBI,annualPlanEntityHistoric.getTaxRevenuePercentage()));
            LOGGER.info("successfully got the annual plan for id " + annualPlanEntity.getId());

        }
        return entityList;

    }
}
