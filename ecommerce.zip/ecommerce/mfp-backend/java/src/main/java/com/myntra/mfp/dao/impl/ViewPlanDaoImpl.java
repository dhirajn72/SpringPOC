/**
 * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *
 * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 **/
package com.myntra.mfp.dao.impl;

import com.myntra.commons.dao.impl.BaseDAOImpl;
import com.myntra.mfp.dao.ViewPlanDao;
import com.myntra.mfp.entity.ViewPlan;
import com.myntra.mfp.entry.ViewPlanEntry;

import javax.persistence.Query;
import java.util.List;


/**
 * @author Dhiraj
 * @date 24/11/17
 */
public class ViewPlanDaoImpl extends BaseDAOImpl<ViewPlan> implements ViewPlanDao {

    @Override
    public List<ViewPlan> getAllAnnualPlans() {
        Query query = this.getEntityManager(false).createNamedQuery(ViewPlan.FIND_ALL_ANNUAL_PLANS);
        return query.getResultList();
    }

    @Override
    public List<ViewPlan> getAllAnnualPlans(ViewPlanEntry viewPlanEntry) {

        List<ViewPlan> planList = null;
        if ((viewPlanEntry.getChannelsEntity().getId()!=null && !String.valueOf(viewPlanEntry.getChannelsEntity().getId()).trim().equals(""))
                && (viewPlanEntry.getFinancialYearEntity().getId()!=null && !String.valueOf(viewPlanEntry.getFinancialYearEntity().getId()).trim().equals(""))) {
            Query query = this.getEntityManager(false).createNamedQuery(ViewPlan.FIND_ALL_ANNUAL_PLANS_FOR_YEAR_AND_CHANNEL);
            query.setParameter("financialYearId", viewPlanEntry.getFinancialYearEntity().getId());
            query.setParameter("channelsId", viewPlanEntry.getChannelsEntity().getId());
            planList = query.getResultList();
            return planList;
        }
        else if (viewPlanEntry.getChannelsEntity().getId()!=null && !String.valueOf(viewPlanEntry.getChannelsEntity().getId()).trim().equals("")
                || viewPlanEntry.getFinancialYearEntity().getId() ==null || String.valueOf(viewPlanEntry.getFinancialYearEntity().getId()).trim().equals("")) {
            Query query = this.getEntityManager(false).createNamedQuery(ViewPlan.FIND_ALL_ANNUAL_PLANS_FOR_CHANNEL);
            query.setParameter("channelsId", viewPlanEntry.getChannelsEntity().getId());
            planList = query.getResultList();
            return planList;
        }
        else if (viewPlanEntry.getFinancialYearEntity().getId()!=null && !String.valueOf(viewPlanEntry.getFinancialYearEntity().getId()).trim().equals("")
                || viewPlanEntry.getChannelsEntity().getId()==null || String.valueOf(viewPlanEntry.getChannelsEntity().getId()).trim().equals("")) {
            Query query = this.getEntityManager(false).createNamedQuery(ViewPlan.FIND_ALL_ANNUAL_PLANS_FOR_YEAR);
            query.setParameter("financialYearId", viewPlanEntry.getFinancialYearEntity().getId());
            planList = query.getResultList();
            return planList;
        }
        return planList;
    }
}
