/*
 *
 *  *  Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved. MYNTRA
 *  *  PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.manager.impl;

import com.myntra.commons.exception.ManagerException;
import com.myntra.commons.manager.impl.BaseManagerImpl;
import com.myntra.mfp.dao.ViewPlanDao;
import com.myntra.mfp.entity.*;
import com.myntra.mfp.entry.*;
import com.myntra.mfp.manager.ViewPlanManager;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Dhiraj
 * @date 24/11/17
 */
public class ViewPlanManagerImpl extends BaseManagerImpl<ViewPlanEntry, ViewPlan> implements ViewPlanManager {

    @Override
    public List<ViewPlanEntry> viewAnualPlan() {
        List<ViewPlanEntry> planEntries = new ArrayList<ViewPlanEntry>();
        List<ViewPlan> planList = ((ViewPlanDao) getDao()).getAllAnnualPlans();
        for (ViewPlan viewPlan : planList) {
            ViewPlanEntry viewPlanEntry = this.convertEntityToEntry(viewPlan);
            planEntries.add(viewPlanEntry);
        }
        return planEntries;
    }

    private ViewPlanEntry convertEntityToEntry(ViewPlan viewPlan) {
        ViewPlanEntry viewPlanEntry = super.convertToEntry(viewPlan);
        viewPlanEntry.setFinancialYearEntity(convertEntityToEntry(viewPlan.getFinancialYearEntity()));
        viewPlanEntry.setChannelsEntity(convertEntityToEntry(viewPlan.getChannelsEntity()));
        viewPlanEntry.setStatusEntity(convertEntityToEntry(viewPlan.getStatusEntity()));
        return viewPlanEntry;
    }

    private FinalcialYearEntry convertEntityToEntry(FinancialYearEntity finalcialYearEntity) {
        return new FinalcialYearEntry(finalcialYearEntity.getId(), finalcialYearEntity.getCreatedBy(), finalcialYearEntity.getCreatedOn(),
                finalcialYearEntity.getLastModifiedOn(), finalcialYearEntity.getFinancial_year(), finalcialYearEntity.getLast_modified_by());
    }
    private ChannelEntry convertEntityToEntry(ChannelEntity channelEntry) {
        return new ChannelEntry(channelEntry.getId(),channelEntry.getCreatedBy(), channelEntry.getCreatedOn(), channelEntry.getLastModifiedOn(), channelEntry.getChannel_name(), channelEntry.getLast_modified_by());
    }

    private PlanStatusEntry convertEntityToEntry(PlanStatusEntity planStatusEntity) {
        return new PlanStatusEntry(planStatusEntity.getId(), planStatusEntity.getCreatedBy(), planStatusEntity.getCreatedOn(), planStatusEntity.getStatusName(),planStatusEntity.getLast_modified_by());
    }

    @Override
    public List<ViewPlanEntry> viewAnualPlan(ViewPlanEntry viewPlanEntry) throws ManagerException {

        List<ViewPlanEntry> planEntries = new ArrayList<ViewPlanEntry>();
        List<ViewPlan> planList = ((ViewPlanDao) getDao()).getAllAnnualPlans(viewPlanEntry);
        for (ViewPlan viewPlan : planList) {
            ViewPlanEntry vpe = this.convertEntityToEntry(viewPlan);
            planEntries.add(vpe);
        }
        return planEntries;
    }
}