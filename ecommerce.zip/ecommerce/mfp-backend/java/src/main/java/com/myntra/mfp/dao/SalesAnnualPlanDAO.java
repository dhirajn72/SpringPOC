package com.myntra.mfp.dao;


import com.myntra.commons.dao.BaseDAO;
import com.myntra.mfp.entity.SalesAnnualPlanEntity;

/**
 * @Author-Dinesh
 * @Date-30-11-2017
 */

public interface SalesAnnualPlanDAO extends BaseDAO<SalesAnnualPlanEntity>{

}
