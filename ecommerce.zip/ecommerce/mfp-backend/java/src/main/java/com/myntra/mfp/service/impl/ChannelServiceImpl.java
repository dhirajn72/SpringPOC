/*
 *
 *  *
 *  * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *  *
 *  * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.service.impl;

import com.myntra.commons.codes.StatusResponse;
import com.myntra.commons.exception.ManagerException;
import com.myntra.commons.service.impl.BaseServiceImpl;
import com.myntra.mfp.code.MfpErrorCode;
import com.myntra.mfp.code.MfpSuccessCode;
import com.myntra.mfp.entity.ChannelEntity;
import com.myntra.mfp.entry.ChannelEntry;
import com.myntra.mfp.manager.ChannelManager;
import com.myntra.mfp.response.ChannelResponse;
import com.myntra.mfp.service.ChannelService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * @author Dhiraj
 * @date 04/12/17
 */
public class ChannelServiceImpl extends BaseServiceImpl<ChannelResponse,ChannelEntry,ChannelEntity>  implements ChannelService{

    private static final Logger LOGGER = LoggerFactory.getLogger(ChannelServiceImpl.class.getName());

    public ChannelServiceImpl() {
        super(MfpSuccessCode.SUCCESS, MfpSuccessCode.SUCCESS, MfpSuccessCode.SUCCESS, MfpErrorCode.RECORD_NOT_FOUND);
    }

    @Override
    protected ChannelResponse createResponse(List<ChannelEntry> entries) {
        return null;
    }

    @Override
    public ChannelResponse getAllChannels() {
        ChannelResponse channelResponse = new ChannelResponse();
        try {
            List<ChannelEntry> entries = ((ChannelManager)manager).getAllChannels();
            if(entries.isEmpty()){
                channelResponse.setStatus(new StatusResponse(MfpErrorCode.RECORDS_NOT_FOUND, StatusResponse.Type.SUCCESS, entries.size()));
                return  channelResponse;
            }
            channelResponse.setData(entries);
            channelResponse.setStatus(new StatusResponse(MfpSuccessCode.SUCCESS, StatusResponse.Type.SUCCESS,entries.size()));
        }catch (ManagerException e) {
            LOGGER.info("Error while fetching channels");
            channelResponse.setStatus(e.getStatusResponse());
        }
        return channelResponse;
    }
}
