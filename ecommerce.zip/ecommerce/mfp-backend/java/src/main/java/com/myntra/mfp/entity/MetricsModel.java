package com.myntra.mfp.entity;

public class MetricsModel {

    private double gmv;

    private double mrpPerUnit;

    private double aisp;

    private double cf;

    private double taxRecovery;

    private double bmContractual;

    private String bmType;

    private double vfContractual;

    private double royalty;

    private double tax;

    private double mrp;

    private double mrpExTax;

    private double ipp;

    private double bmNotional;

    private double cogs;

    private double gmPercent;

    private int forwardDOH;

    private int openingInventory;

    private int unitsSold;

    private int currentInventory;

    private int newStylesAdded;

    private int month;

    private int week;

    private int day;

    private boolean isDataPresent;


    public boolean isDataPresent() {
        return isDataPresent;
    }

    public void setDataPresent(boolean dataPresent) {
        isDataPresent = dataPresent;
    }



    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getWeek() {
        return week;
    }

    public void setWeek(int week) {
        this.week = week;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }




    public MetricsModel() {
    }

    public double getGmv() {
        return gmv;
    }

    public void setGmv(double gmv) {
        this.gmv = gmv;
    }

    public double getMrpPerUnit() {
        return mrpPerUnit;
    }

    public void setMrpPerUnit(double mrpPerUnit) {
        this.mrpPerUnit = mrpPerUnit;
    }

    public double getAisp() {
        return aisp;
    }

    public void setAisp(double aisp) {
        this.aisp = aisp;
    }

    public double getCf() {
        return cf;
    }

    public void setCf(double cf) {
        this.cf = cf;
    }

    public double getTaxRecovery() {
        return taxRecovery;
    }

    public void setTaxRecovery(double taxRecovery) {
        this.taxRecovery = taxRecovery;
    }

    public double getBmContractual() {
        return bmContractual;
    }

    public void setBmContractual(double bmContractual) {
        this.bmContractual = bmContractual;
    }

    public String getBmType() {
        return bmType;
    }

    public void setBmType(String bmType) {
        this.bmType = bmType;
    }

    public double getVfContractual() {
        return vfContractual;
    }

    public void setVfContractual(double vfContractual) {
        this.vfContractual = vfContractual;
    }

    public double getRoyalty() {
        return royalty;
    }

    public void setRoyalty(double royalty) {
        this.royalty = royalty;
    }

    public double getTax() {
        return tax;
    }

    public void setTax(double tax) {
        this.tax = tax;
    }

    public double getMrp() {
        return mrp;
    }

    public void setMrp(double mrp) {
        this.mrp = mrp;
    }

    public double getMrpExTax() {
        return mrpExTax;
    }

    public void setMrpExTax(double mrpExTax) {
        this.mrpExTax = mrpExTax;
    }

    public double getIpp() {
        return ipp;
    }

    public void setIpp(double ipp) {
        this.ipp = ipp;
    }

    public double getBmNotional() {
        return bmNotional;
    }

    public void setBmNotional(double bmNotional) {
        this.bmNotional = bmNotional;
    }

    public double getCogs() {
        return cogs;
    }

    public void setCogs(double cogs) {
        this.cogs = cogs;
    }

    public double getGmPercent() {
        return gmPercent;
    }

    public void setGmPercent(double gmPercent) {
        this.gmPercent = gmPercent;
    }

    public int getForwardDOH() {
        return forwardDOH;
    }

    public void setForwardDOH(int forwardDOH) {
        this.forwardDOH = forwardDOH;
    }

    public int getOpeningInventory() {
        return openingInventory;
    }

    public void setOpeningInventory(int openingInventory) {
        this.openingInventory = openingInventory;
    }

    public int getUnitsSold() {
        return unitsSold;
    }

    public void setUnitsSold(int unitsSold) {
        this.unitsSold = unitsSold;
    }

    public int getCurrentInventory() {
        return currentInventory;
    }

    public void setCurrentInventory(int currentInventory) {
        this.currentInventory = currentInventory;
    }

    public int getNewStylesAdded() {
        return newStylesAdded;
    }

    public void setNewStylesAdded(int newStylesAdded) {
        this.newStylesAdded = newStylesAdded;
    }

    public int getLiveStylesMonthEnd() {
        return liveStylesMonthEnd;
    }

    public void setLiveStylesMonthEnd(int liveStylesMonthEnd) {
        this.liveStylesMonthEnd = liveStylesMonthEnd;
    }

    private int liveStylesMonthEnd;
}
