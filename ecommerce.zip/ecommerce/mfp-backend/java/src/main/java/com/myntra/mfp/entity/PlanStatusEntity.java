/*
 *
 *  *  Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved. MYNTRA
 *  *  PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.entity;

import com.myntra.commons.entities.BaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;

/**
 * @author Dhiraj
 * @date 01/12/17
 */
@Entity
@Table(name = "mfp_plan_status")
public class PlanStatusEntity extends BaseEntity {

    @Column(name = "status_name")
    private String statusName;

    @Column(name = "last_modified_by")
    private String last_modified_by;


    public PlanStatusEntity() {
    }


    public PlanStatusEntity(Long id, String createdBy, Date createdOn, String statusName, String last_modified_by) {
        super(id, createdBy, createdOn);
        this.statusName = statusName;
        this.last_modified_by = last_modified_by;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public String getLast_modified_by() {
        return last_modified_by;
    }

    public void setLast_modified_by(String last_modified_by) {
        this.last_modified_by = last_modified_by;
    }
}
