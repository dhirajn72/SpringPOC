package com.myntra.mfp.manager.impl;
import com.myntra.commons.exception.DaoException;
import com.myntra.commons.manager.impl.BaseManagerImpl;
import com.myntra.mfp.entity.SalesAnnualPlanEntity;
import com.myntra.mfp.entry.SalesAnnualPlanEntry;
import com.myntra.mfp.manager.SalesAnnualPlanManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/**
 * @Author-Dinesh
 * @Date-30-11-2017
 */

public class SalesAnnualPlanManagerImpl extends BaseManagerImpl<SalesAnnualPlanEntry,SalesAnnualPlanEntity> implements SalesAnnualPlanManager {

    public static final Logger LOGGER = LoggerFactory.getLogger(SalesAnnualPlanManagerImpl.class);


    @Override
    @Transactional
    public void createBulkRecords(List<SalesAnnualPlanEntity> entityList) throws DaoException {

        //inserting records into DB
        this.getDao().bulkCreate(entityList);
        LOGGER.info("inserted Records in Annual Plan");
    }
}
