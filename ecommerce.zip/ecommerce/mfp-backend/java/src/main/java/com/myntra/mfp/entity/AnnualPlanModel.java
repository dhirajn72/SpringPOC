package com.myntra.mfp.entity;


import java.util.Date;
import java.util.List;

public class AnnualPlanModel {

    private int financialYear;

    private int channel;

    private int source;

    private int bussinessUnit;

    private String bussinessUnitValue;

    private int brandGroup;

    private String brandGroupValue;

    private int brand;

    private String brandValue;

    private int masterCategory;

    private String masterCategoryValue;

    private int gender;

    private String genderValue;

    private int article;

    private String articleValue;

    private int commercialType;

    private String commercialTypeValue;

    private int pricePoint;

    List<MetricsModel> metricsModel;


    public List<MetricsModel> getMetricsModel() {
        return metricsModel;
    }

    public void setMetricsModel(List<MetricsModel> metricsModel) {
        this.metricsModel = metricsModel;
    }





    public String getBussinessUnitValue() {
        return bussinessUnitValue;
    }

    public void setBussinessUnitValue(String bussinessUnitValue) {
        this.bussinessUnitValue = bussinessUnitValue;
    }

    public String getBrandGroupValue() {
        return brandGroupValue;
    }

    public void setBrandGroupValue(String brandGroupValue) {
        this.brandGroupValue = brandGroupValue;
    }

    public String getBrandValue() {
        return brandValue;
    }

    public void setBrandValue(String brandValue) {
        this.brandValue = brandValue;
    }

    public String getMasterCategoryValue() {
        return masterCategoryValue;
    }

    public void setMasterCategoryValue(String masterCategoryValue) {
        this.masterCategoryValue = masterCategoryValue;
    }

    public String getGenderValue() {
        return genderValue;
    }

    public void setGenderValue(String genderValue) {
        this.genderValue = genderValue;
    }

    public String getArticleValue() {
        return articleValue;
    }

    public void setArticleValue(String articleValue) {
        this.articleValue = articleValue;
    }

    public String getCommercialTypeValue() {
        return commercialTypeValue;
    }

    public void setCommercialTypeValue(String commercialTypeValue) {
        this.commercialTypeValue = commercialTypeValue;
    }



    public int getFinancialYear() {
        return financialYear;
    }

    public void setFinancialYear(int financialYear) {
        this.financialYear = financialYear;
    }

    public int getChannel() {
        return channel;
    }

    public void setChannel(int channel) {
        this.channel = channel;
    }

    public int getSource() {
        return source;
    }

    public void setSource(int source) {
        this.source = source;
    }

    public int getBussinessUnit() {
        return bussinessUnit;
    }

    public void setBussinessUnit(int bussinessUnit) {
        this.bussinessUnit = bussinessUnit;
    }

    public int getBrandGroup() {
        return brandGroup;
    }

    public void setBrandGroup(int brandGroup) {
        this.brandGroup = brandGroup;
    }

    public int getBrand() {
        return brand;
    }

    public void setBrand(int brand) {
        this.brand = brand;
    }

    public int getMasterCategory() {
        return masterCategory;
    }

    public void setMasterCategory(int masterCategory) {
        this.masterCategory = masterCategory;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public int getArticle() {
        return article;
    }

    public void setArticle(int article) {
        this.article = article;
    }

    public int getCommercialType() {
        return commercialType;
    }

    public void setCommercialType(int commercialType) {
        this.commercialType = commercialType;
    }

    public int getPricePoint() {
        return pricePoint;
    }

    public void setPricePoint(int pricePoint) {
        this.pricePoint = pricePoint;
    }


    public Date getDateAP() {
        return dateAP;
    }

    public void setDateAP(Date dateAP) {
        this.dateAP = dateAP;
    }

    private Date dateAP;
}
