/**
 *
 * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *
 * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 **/
package com.myntra.mfp.service;

import com.myntra.commons.service.BaseService;
import com.myntra.mfp.entity.ViewPlan;
import com.myntra.mfp.entry.ViewPlanEntry;
import com.myntra.mfp.response.ViewAnualPlanResponse;
import com.myntra.mfp.response.ViewPlanResponse;

import javax.ws.rs.*;

/**
 * @author Dhiraj
 * @date 23/11/17
 */


@Path("/viewplan")
public interface ViewPlanService extends BaseService<ViewPlanResponse, ViewPlanEntry, ViewPlan>{

    @GET
    @Produces("text/plain")
    @Path("/hello")
    public String getHelloWorld();


    @GET
    @Path("/viewplanlist")
    @Produces({"application/json","application/xml"})
    @Consumes({"application/json","application/xml"})
    public ViewPlanResponse viewAnualPlan();


    @POST
    @Path("/viewplanyearschannels")
    @Produces({"application/json","application/xml"})
    @Consumes({"application/json","application/xml"})
    public ViewPlanResponse viewAnualPlan(ViewPlanEntry viewPlanEntry);



}
