package com.myntra.mfp.service.impl;

import com.myntra.commons.codes.StatusResponse;
import com.myntra.commons.exception.ManagerException;
import com.myntra.commons.service.impl.BaseServiceImpl;
import com.myntra.mfp.code.MfpErrorCode;
import com.myntra.mfp.code.MfpSuccessCode;
import com.myntra.mfp.entity.FinancialYearEntity;
import com.myntra.mfp.entry.FinalcialYearEntry;
import com.myntra.mfp.manager.FinancialYearManager;
import com.myntra.mfp.response.FinancialYearResponse;
import com.myntra.mfp.service.FinancialYearService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * @author Dhiraj
 * @date 04/12/17
 */
public class FinancialYearServiceImpl extends BaseServiceImpl<FinancialYearResponse,FinalcialYearEntry,FinancialYearEntity> implements FinancialYearService{

    private static final Logger LOGGER = LoggerFactory.getLogger(FinancialYearServiceImpl.class.getName());

    public FinancialYearServiceImpl() {
        super(MfpSuccessCode.SUCCESS, MfpSuccessCode.SUCCESS, MfpSuccessCode.SUCCESS, MfpErrorCode.RECORD_NOT_FOUND);
    }

    @Override
    protected FinancialYearResponse createResponse(List<FinalcialYearEntry> entries) {
        return null;
    }

    @Override
    public FinancialYearResponse getAllFinancialYears() {
        FinancialYearResponse yearResponse = new FinancialYearResponse();

        try{
            List<FinalcialYearEntry> yearEntries =  ((FinancialYearManager)manager).getAllYears();
            if(yearEntries.isEmpty()){
                yearResponse.setStatus(new StatusResponse(MfpErrorCode.RECORDS_NOT_FOUND, StatusResponse.Type.SUCCESS, yearEntries.size()));
                return yearResponse;
            }
            yearResponse.setData(yearEntries);
            yearResponse.setStatus(new StatusResponse(MfpSuccessCode.SUCCESS, StatusResponse.Type.SUCCESS, yearEntries.size()));
        }catch (ManagerException e){
            LOGGER.error("Error while fetching financial years");
            yearResponse.setStatus(e.getStatusResponse());
        }
        return yearResponse;
    }
}
