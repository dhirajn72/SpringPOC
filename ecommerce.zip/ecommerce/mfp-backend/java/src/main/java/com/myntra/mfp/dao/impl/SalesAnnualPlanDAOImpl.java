package com.myntra.mfp.dao.impl;

import com.myntra.commons.dao.impl.BaseDAOImpl;
import com.myntra.mfp.dao.SalesAnnualPlanDAO;
import com.myntra.mfp.entity.SalesAnnualPlanEntity;

/**
 * @Author-Dinesh
 * @Date-30-11-2017
 */


public class SalesAnnualPlanDAOImpl extends BaseDAOImpl<SalesAnnualPlanEntity> implements SalesAnnualPlanDAO {

}
