package com.myntra.mfp.manager;

import com.myntra.commons.exception.DaoException;
import com.myntra.mfp.entity.AnnualPlanModel;
import marvin.client.entry.UserViewEntry;

import java.sql.SQLException;
import java.util.List;

public interface AggregationServiceManager {


    List<AnnualPlanModel> getAggregationOnUserAxis(UserViewEntry userViewEntry, Integer page, Integer pageLimit) throws DaoException, SQLException;



}
