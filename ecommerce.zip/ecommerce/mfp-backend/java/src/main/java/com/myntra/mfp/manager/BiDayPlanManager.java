package com.myntra.mfp.manager;
import com.myntra.commons.manager.BaseManager;
import com.myntra.mfp.entity.SalesAnnualPlanEntity;
import com.myntra.mfp.entity.BiDayPlanEntity;
import com.myntra.mfp.entry.BiDayPlanEntry;

import java.util.List;

/**
 * @Author-Dinesh
 * @Date-30-11-2017
 */

public interface BiDayPlanManager extends BaseManager<BiDayPlanEntry, BiDayPlanEntity>{

    public List<SalesAnnualPlanEntity> getAnnualPlanWithUpdatedMetrics(Double AOPTarget, Double gmv, Integer startIndex, Integer maxResult);

    public Double getTotalSumOfGmvOfHistoricData();


}
