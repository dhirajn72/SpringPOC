package com.myntra.mfp.service.impl;

import com.myntra.mfp.service.SalesService;
import com.myntra.mfp.utils.SalesFormulae;

/**
 * @Author-Dinesh
 * @Date-4-12-2017
 */


public class SalesServiceImpl implements SalesService{

    private SalesFormulae salesformulae;

    public void setSalesformulae(SalesFormulae salesformulae) {
        this.salesformulae = salesformulae;
    }

    @Override
    public String getSalesCalculations() {

        //calculating rule matrics for each with hardcoded values
        Double mrp = salesformulae.calculateMrp(10.0,0.3,0.1,0.2,0.1);
        Double unitsSold = salesformulae.calculateUnitsSold(10.0,5.0);
        Double aisp = salesformulae.calculateAisp(10.0,5.0);
        Double mrpExTaxOR = salesformulae.calculateMrpExTaxOR(10.0,5.0);
        Double mrpExTaxSOR = salesformulae.calculateMrpExTaxSOR(10.0,5.0);
        Double vf_OR = salesformulae.calculateVfOR(10.0,5.0);
        Double vf_SOR = salesformulae.calculateVfSOR(10.0,5.0);
        Double bmpercentnotional_SOR = salesformulae.calculateBmPercentNotionalSOR(0.3,0.1,0.4);
        Double bmpercentnotional_OR = salesformulae.calculateBmPercentNotionalOR(0.2,0.4);
        Double cogs = salesformulae.calculateCogs(0.4,0.2);
        Double gmpercent = salesformulae.calculateGmPercent(3.0,2.0,10.0);
        Double rgmunit = salesformulae.calculateRgmUnit(3.0,2.0,4.0);
        Double ipp_OR = salesformulae.calculateIppOR(10.0,5.0,5.0);
        Double ipp_SOR = salesformulae.calculateIppSOR(10.0,5.0,5.0);
        Double tax_OR= salesformulae.calculateTaxOR(1.0,2.0);
        Double tax_SOR= salesformulae.calculateTaxSOR(1.0,2.0);

        return "result:"+"\n"+" mrp:"+mrp+" unitsSold:"+unitsSold+" aisp:"+aisp+" mrpextaxOR:"+mrpExTaxOR+ "mrpextaxSOR"+mrpExTaxSOR+" vf1:"+vf_OR+" vf2:"+vf_SOR+"\n"
                +" bmpercentnotional1:"+bmpercentnotional_SOR+" bmpercentnotional2:"+bmpercentnotional_OR+" cogs:"+cogs+"\n"
                +" gmpercent:"+gmpercent+" rgmunit:"+rgmunit+"ippOR"+ipp_OR+"ipp_SOR"+ipp_SOR+"tax_OR"+tax_OR+"tax_SOR"+tax_SOR;

    }
}
