package com.myntra.mfp.dao;

import com.myntra.commons.dao.BaseDAO;
import com.myntra.mfp.entity.AnnualPlanEntity;
import com.myntra.mfp.entity.AnnualPlanModel;

public interface AggregationDAO extends BaseDAO<AnnualPlanEntity> {
}
