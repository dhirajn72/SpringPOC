/*
 *
 *  *
 *  * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *  *
 *  * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.manager.impl;

import com.myntra.commons.manager.impl.BaseManagerImpl;
import com.myntra.mfp.dao.ChannelDao;
import com.myntra.mfp.entity.ChannelEntity;
import com.myntra.mfp.entry.ChannelEntry;
import com.myntra.mfp.manager.ChannelManager;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Dhiraj
 * @date 04/12/17
 */
public class ChannelManagerImpl extends BaseManagerImpl<ChannelEntry,ChannelEntity> implements ChannelManager {
    @Override
    public List<ChannelEntry> getAllChannels() {
        List<ChannelEntity> entities = ((ChannelDao)getDao()).getAllChannels();
        List<ChannelEntry> entries= new ArrayList<>();
        for(ChannelEntity entity:entities){
            entries.add(super.convertToEntry(entity));
        }
        return entries;
    }
}
