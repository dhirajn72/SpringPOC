/**
 *
 * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *
 * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 **/


package com.myntra.mfp.entity;

import com.myntra.commons.entities.BaseEntity;
import javax.persistence.*;
import java.util.Date;

/**
 * @author Dhiraj
 * @date 29/11/17
 */

@Entity
@Table(name="financial_year_mstr")
@NamedQueries(value = {
        @NamedQuery(name = FinancialYearEntity.GET_ALL_FINANCIAL_YEAR, query = "select fy from FinancialYearEntity fy")
})
public class FinancialYearEntity extends BaseEntity{

    public static final String GET_ALL_FINANCIAL_YEAR="GetAllFinancialYear";

    @Column(name = "financial_year")
    private String financial_year;

    @Column(name = "last_modified_by")
    private String last_modified_by;


    public FinancialYearEntity() {
    }

    public FinancialYearEntity(Long id, String createdBy, Date createdOn, String financial_year, String last_modified_by) {
        super(id, createdBy, createdOn);
        this.financial_year = financial_year;
        this.last_modified_by = last_modified_by;
    }

    public String getFinancial_year() {
        return financial_year;
    }

    public void setFinancial_year(String financial_year) {
        this.financial_year = financial_year;
    }

    public String getLast_modified_by() {
        return last_modified_by;
    }

    public void setLast_modified_by(String last_modified_by) {
        this.last_modified_by = last_modified_by;
    }
}
