package com.myntra.mfp.entry;

public class ClosingInventory {

    private int doh;
    private int net_units_sold;

    public int getDoh() {
        return doh;
    }

    public void setDoh(int doh) {
        this.doh = doh;
    }

    public int getNet_units_sold() {
        return net_units_sold;
    }

    public void setNet_units_sold(int net_units_sold) {
        this.net_units_sold = net_units_sold;
    }
}
