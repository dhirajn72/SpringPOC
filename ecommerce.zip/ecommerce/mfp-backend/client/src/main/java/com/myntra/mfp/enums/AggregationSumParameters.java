package com.myntra.mfp.enums;

public enum AggregationSumParameters {

    GMV("gmv"), //calls constructor with value 1
    IPP("ipp"), //calls constructor with value 2
    COGS ("cogs"), //calls constructor with value 3
    MRP("mrp"); //calls constructor with value 4



    private final String levelCode;

    AggregationSumParameters(String levelCode) {
        this.levelCode = levelCode;
    }

    public String getLevelValue() {
        return this.levelCode;
    }
}
