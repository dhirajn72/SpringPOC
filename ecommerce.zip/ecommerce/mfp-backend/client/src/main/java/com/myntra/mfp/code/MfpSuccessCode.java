/**
 *
 * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *
 * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 **/
package com.myntra.mfp.code;

import com.myntra.commons.codes.ERPSuccessCodes;
import com.myntra.commons.codes.StatusCodes;

/**
 * @author Dhiraj
 * @date 23/11/17
 */
public class MfpSuccessCode extends ERPSuccessCodes {
    private static final String BUNDLE_NAME = "MfpSuccessCodes";

    public MfpSuccessCode(int code, String message) {

        setAll(code, message, BUNDLE_NAME);
    }

    public static final StatusCodes MFP_RECORDS_FOUND = new MfpErrorCode(22000, "RECORDS_FOUND");

}



