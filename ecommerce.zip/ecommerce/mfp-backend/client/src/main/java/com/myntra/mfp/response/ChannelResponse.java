/*
 *
 *  *
 *  * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *  *
 *  * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */
package com.myntra.mfp.response;

import com.myntra.commons.response.AbstractResponse;
import com.myntra.mfp.entry.ChannelEntry;
import com.myntra.mfp.entry.FinalcialYearEntry;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;


/**
 * @author Dhiraj
 * @date 04/12/17
 */

@XmlRootElement(name = "channelResponse")
public class ChannelResponse extends AbstractResponse{

    private List<ChannelEntry> data;

    public ChannelResponse(){

    }

    @XmlElementWrapper(name = "data")
    @XmlElement(name = "channelEntry")
    public List<ChannelEntry> getData() {
        return data;
    }

    public void setData(List<ChannelEntry> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("data", data)
                .append("status", getStatus())
                .toString();
    }
}
