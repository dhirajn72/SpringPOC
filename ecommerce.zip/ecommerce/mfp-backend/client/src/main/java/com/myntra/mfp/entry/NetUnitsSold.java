package com.myntra.mfp.entry;


public class NetUnitsSold {

    private int units_sold_in_days;
    private int return_restocking;
    private int rto_restocking;

    public int getUnits_sold_in_days() {
        return units_sold_in_days;
    }

    public void setUnits_sold_in_days(int units_sold_in_days) {
        this.units_sold_in_days = units_sold_in_days;
    }

    public int getReturn_restocking() {
        return return_restocking;
    }

    public void setReturn_restocking(int return_restocking) {
        this.return_restocking = return_restocking;
    }

    public int getRto_restocking() {
        return rto_restocking;
    }

    public void setRto_restocking(int rto_restocking) {
        this.rto_restocking = rto_restocking;
    }
}
