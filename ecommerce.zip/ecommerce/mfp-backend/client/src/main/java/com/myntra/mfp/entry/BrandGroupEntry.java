/*
 *
 *  *  Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved. MYNTRA
 *  *  PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.entry;


import com.myntra.commons.entries.BaseEntry;

import java.util.Date;

/**
 * @author Dhiraj
 * @date 30/11/17
 */
public class BrandGroupEntry extends BaseEntry{

    private String brnd_grp_name;

    private String last_modified_by;

    public BrandGroupEntry() {
    }

    public BrandGroupEntry(Long id, String createdBy, Date createdOn, Date lastModifiedOn, String brnd_grp_name, String last_modified_by) {
        super(id, createdBy, createdOn, lastModifiedOn);
        this.brnd_grp_name = brnd_grp_name;
        this.last_modified_by = last_modified_by;
    }

    public String getBrnd_grp_name() {
        return brnd_grp_name;
    }

    public void setBrnd_grp_name(String brnd_grp_name) {
        this.brnd_grp_name = brnd_grp_name;
    }

    public String getLast_modified_by() {
        return last_modified_by;
    }

    public void setLast_modified_by(String last_modified_by) {
        this.last_modified_by = last_modified_by;
    }
}
