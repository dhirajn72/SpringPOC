package com.myntra.mfp.entry;

/**
 * @Author-Dinesh
 * @Date-4-12-2017
 */


public class Tax_OR {

    private Double gmv;
    private Double taxRevenuepercentage;

    public Double getGmv() {
        return gmv;
    }

    public void setGmv(Double gmv) {
        this.gmv = gmv;
    }

    public Double getTaxRevenuepercentage() {
        return taxRevenuepercentage;
    }

    public void setTaxRevenuepercentage(Double taxRevenuepercentage) {
        this.taxRevenuepercentage = taxRevenuepercentage;
    }
}


