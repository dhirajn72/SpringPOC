/*
 *
 *  *  Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved. MYNTRA
 *  *  PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.entry;


import com.myntra.commons.entries.BaseEntry;

import java.util.Date;

/**
 * @author Dhiraj
 * @date 30/11/17
 */
public class PricePointEntry extends BaseEntry {

    private String pp_range;

    private String last_modified_by;

    public PricePointEntry() {
    }

    public PricePointEntry(Long id, String createdBy, Date createdOn, Date lastModifiedOn, String pp_range, String last_modified_by) {
        super(id, createdBy, createdOn, lastModifiedOn);
        this.pp_range = pp_range;
        this.last_modified_by = last_modified_by;
    }

    public String getPp_range() {
        return pp_range;
    }

    public void setPp_range(String pp_range) {
        this.pp_range = pp_range;
    }

    public String getLast_modified_by() {
        return last_modified_by;
    }

    public void setLast_modified_by(String last_modified_by) {
        this.last_modified_by = last_modified_by;
    }
}
