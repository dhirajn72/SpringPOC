package com.myntra.mfp.entry;

/**
 * @Author-Dinesh
 * @Date-4-12-2017
 */


public class MrpExTax_SOR {

    private Double mrp;
    private Double tax_percentage;

    public Double getMrp() {
        return mrp;
    }

    public void setMrp(Double mrp) {
        this.mrp = mrp;
    }

    public Double getTax_percentage() {
        return tax_percentage;
    }

    public void setTax_percentage(Double tax_percentage) {
        this.tax_percentage = tax_percentage;
    }
}
