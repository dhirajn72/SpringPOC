package com.myntra.mfp.entry;

/**
 * @Author-Dinesh
 * @Date-4-12-2017
 */


public class Cogs {

    private Double ipp;
    private Double vf;

    public Double getIpp() {
        return ipp;
    }

    public void setIpp(Double ipp) {
        this.ipp = ipp;
    }

    public Double getVf() {
        return vf;
    }

    public void setVf(Double vf) {
        this.vf = vf;
    }
}
