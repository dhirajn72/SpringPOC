package com.myntra.mfp.entry;

public class BmPercentageNotional_OR {

    private Double ipp;
    private Double mrp_ex_tax;

    public Double getIpp() {
        return ipp;
    }

    public void setIpp(Double ipp) {
        this.ipp = ipp;
    }

    public Double getMrp_ex_tax() {
        return mrp_ex_tax;
    }

    public void setMrp_ex_tax(Double mrp_ex_tax) {
        this.mrp_ex_tax = mrp_ex_tax;
    }
}
