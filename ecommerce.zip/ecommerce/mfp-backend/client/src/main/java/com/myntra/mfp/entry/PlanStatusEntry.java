/*
 *
 *  *  Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved. MYNTRA
 *  *  PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.entry;

import com.myntra.commons.entities.BaseEntity;

import javax.persistence.Column;
import java.util.Date;

/**
 * @author Dhiraj
 * @date 01/12/17
 */

public class PlanStatusEntry extends BaseEntity {

    private String statusName;

    private String last_modified_by;

    public PlanStatusEntry() {
    }

    public PlanStatusEntry(Long id, String createdBy, Date createdOn, String statusName, String last_modified_by) {
        super(id, createdBy, createdOn);
        this.statusName = statusName;
        this.last_modified_by = last_modified_by;
    }


    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public String getLast_modified_by() {
        return last_modified_by;
    }

    public void setLast_modified_by(String last_modified_by) {
        this.last_modified_by = last_modified_by;
    }
}