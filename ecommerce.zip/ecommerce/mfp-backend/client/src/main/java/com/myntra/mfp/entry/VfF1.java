package com.myntra.mfp.entry;

public class VfF1 {

    private Double vf_percentage;
    private Double mrp;

    public Double getVf_percentage() {
        return vf_percentage;
    }

    public void setVf_percentage(Double vf_percentage) {
        this.vf_percentage = vf_percentage;
    }

    public Double getMrp() {
        return mrp;
    }

    public void setMrp(Double mrp) {
        this.mrp = mrp;
    }
}
