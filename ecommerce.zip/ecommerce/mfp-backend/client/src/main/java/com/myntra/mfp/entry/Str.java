package com.myntra.mfp.entry;

public class Str {

    private int gross_units_sold;
    private int closing;

    public int getGross_units_sold() {
        return gross_units_sold;
    }

    public void setGross_units_sold(int gross_units_sold) {
        this.gross_units_sold = gross_units_sold;
    }

    public int getClosing() {
        return closing;
    }

    public void setClosing(int closing) {
        this.closing = closing;
    }
}
