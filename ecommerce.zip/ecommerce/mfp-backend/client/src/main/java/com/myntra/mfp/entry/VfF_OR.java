package com.myntra.mfp.entry;

/**
 * @Author-Dinesh
 * @Date-4-12-2017
 */

public class VfF_OR {

    private Double vf_percentage;
    private Double mrp;

    public Double getVf_percentage() {
        return vf_percentage;
    }

    public void setVf_percentage(Double vf_percentage) {
        this.vf_percentage = vf_percentage;
    }

    public Double getMrp() {
        return mrp;
    }

    public void setMrp(Double mrp) {
        this.mrp = mrp;
    }
}
