package com.myntra.mfp.enums;

public enum AggregationWeightedAvgParameters {

    MRP_EX_TAX("mrp_ex_tax"), //calls constructor with value 1
    DISCOUNT("discount"), //calls constructor with value 2
    TAX_RECOVERY ("tax_recovery"), //calls constructor with value 3
    BM_CONTRACTUAL("bm_contractual"), //calls constructor with value 4
    MRP_PER_UNIT("mrp_per_unit"); //calls constructor with value 4





    private final String levelCode;

    AggregationWeightedAvgParameters(String levelCode) {
        this.levelCode = levelCode;
    }

    public String getLevelValue() {
        return this.levelCode;
    }
}
