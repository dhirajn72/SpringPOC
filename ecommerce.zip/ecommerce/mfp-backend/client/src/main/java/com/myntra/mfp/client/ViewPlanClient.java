package com.myntra.mfp.client;

import com.myntra.commons.client.BaseWebClient;
import com.myntra.commons.exception.ERPServiceException;
import com.myntra.commons.utils.Context;
import com.myntra.mfp.response.ViewPlanResponse;
import org.junit.Test;

/**
 * @author Dhiraj
 * @date 28/11/17
 */
public class ViewPlanClient {
    private static final String DEFAULT_URL_KEY = "myntra-mfp-service";

    public static ViewPlanResponse viewAnualPlan() throws ERPServiceException {
        BaseWebClient client = new BaseWebClient(null, DEFAULT_URL_KEY, Context.getContextInfo());
        client.path("/mfp/viewplan");
        return (ViewPlanResponse) client.get(ViewPlanResponse.class);
    }
}

