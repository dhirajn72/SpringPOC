/**
 *
 * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *
 * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 **/
package com.myntra.mfp.response;

import com.myntra.commons.response.AbstractResponse;
import com.myntra.mfp.entry.FinalcialYearEntry;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;


/**
 * @author Dhiraj
 * @date 04/12/17
 */

@XmlRootElement(name = "financialYearResponse")
public class FinancialYearResponse extends AbstractResponse{

    private List<FinalcialYearEntry> data;

    public FinancialYearResponse(){

    }

    @XmlElementWrapper(name = "data")
    @XmlElement(name = "financialYearEntry")
    public List<FinalcialYearEntry> getData() {
        return data;
    }

    public void setData(List<FinalcialYearEntry> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.MULTI_LINE_STYLE)
                .append("data", data)
                .append("status", getStatus())
                .toString();
    }
}
