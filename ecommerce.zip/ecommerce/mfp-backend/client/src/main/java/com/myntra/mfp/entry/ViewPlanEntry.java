/*
 *
 *  *  Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved. MYNTRA
 *  *  PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */
package com.myntra.mfp.entry;

import com.myntra.commons.entries.BaseEntry;


import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;


/**
 * @author Dhiraj
 * @date 23/11/17
 */

@XmlRootElement(name = "viewPlanEntry")
public class ViewPlanEntry extends BaseEntry {

    private String approved_by;

    private String last_modified_by;

    private FinalcialYearEntry financialYearEntity;

    private ChannelEntry channelsEntity;

    private PlanStatusEntry statusEntity;

    public ViewPlanEntry(){}


    public ViewPlanEntry(Long id, String createdBy, Date createdOn, Date lastModifiedOn, String approved_by, String last_modified_by, FinalcialYearEntry financialYearEntity, ChannelEntry channelsEntity, PlanStatusEntry statusEntity) {
        super(id, createdBy, createdOn, lastModifiedOn);
        this.approved_by = approved_by;
        this.last_modified_by = last_modified_by;
        this.financialYearEntity = financialYearEntity;
        this.channelsEntity = channelsEntity;
        this.statusEntity = statusEntity;
    }

    public String getApproved_by() {
        return approved_by;
    }

    public void setApproved_by(String approved_by) {
        this.approved_by = approved_by;
    }

    public String getLast_modified_by() {
        return last_modified_by;
    }

    public void setLast_modified_by(String last_modified_by) {
        this.last_modified_by = last_modified_by;
    }

    public FinalcialYearEntry getFinancialYearEntity() {
        return financialYearEntity;
    }

    public void setFinancialYearEntity(FinalcialYearEntry financialYearEntity) {
        this.financialYearEntity = financialYearEntity;
    }

    public ChannelEntry getChannelsEntity() {
        return channelsEntity;
    }

    public void setChannelsEntity(ChannelEntry channelsEntity) {
        this.channelsEntity = channelsEntity;
    }

    public PlanStatusEntry getStatusEntity() {
        return statusEntity;
    }

    public void setStatusEntity(PlanStatusEntry statusEntity) {
        this.statusEntity = statusEntity;
    }
}
