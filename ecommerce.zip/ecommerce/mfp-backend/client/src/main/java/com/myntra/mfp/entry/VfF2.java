package com.myntra.mfp.entry;

public class VfF2 {

    private Double vf_percentage;
    private Double ipp;

    public Double getVf_percentage() {
        return vf_percentage;
    }

    public void setVf_percentage(Double vf_percentage) {
        this.vf_percentage = vf_percentage;
    }

    public Double getIpp() {
        return ipp;
    }

    public void setIpp(Double ipp) {
        this.ipp = ipp;
    }
}
