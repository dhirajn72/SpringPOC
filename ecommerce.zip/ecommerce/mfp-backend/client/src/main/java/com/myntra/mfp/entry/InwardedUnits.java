package com.myntra.mfp.entry;

public class InwardedUnits {

    private int closing_inv;
    private int opening_inv;
    private int new_units_sold;
    private int rtv;
    private int ret_restock;

    public int getClosing_inv() {
        return closing_inv;
    }

    public void setClosing_inv(int closing_inv) {
        this.closing_inv = closing_inv;
    }

    public int getOpening_inv() {
        return opening_inv;
    }

    public void setOpening_inv(int opening_inv) {
        this.opening_inv = opening_inv;
    }

    public int getNew_units_sold() {
        return new_units_sold;
    }

    public void setNew_units_sold(int new_units_sold) {
        this.new_units_sold = new_units_sold;
    }

    public int getRtv() {
        return rtv;
    }

    public void setRtv(int rtv) {
        this.rtv = rtv;
    }

    public int getRet_restock() {
        return ret_restock;
    }

    public void setRet_restock(int ret_restock) {
        this.ret_restock = ret_restock;
    }

    public int getRto_restock() {
        return rto_restock;
    }

    public void setRto_restock(int rto_restock) {
        this.rto_restock = rto_restock;
    }

    private int rto_restock;

}
