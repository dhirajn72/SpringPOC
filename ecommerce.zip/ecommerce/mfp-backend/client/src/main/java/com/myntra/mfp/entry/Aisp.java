package com.myntra.mfp.entry;


/**
 * @Author-Dinesh
 * @Date-4-12-2017
 */

public class Aisp {

    private Double gmv;
    private Double units_sold;

    public Double getGmv() {
        return gmv;
    }

    public void setGmv(Double gmv) {
        this.gmv = gmv;
    }

    public Double getUnits_sold() {
        return units_sold;
    }

    public void setUnits_sold(Double units_sold) {
        this.units_sold = units_sold;
    }
}
