package com.myntra.mfp.entry;

/**
 * @Author-Dinesh
 * @Date-4-12-2017
 */

public class Mrp {

    private Double gmv;
    private Double tax_Revenue_percentage;
    private Double tax_recovery_percentage;
    private Double vf;
    private Double cf;

    public Double getGmv() {
        return gmv;
    }

    public void setGmv(Double gmv) {
        this.gmv = gmv;
    }

    public Double getTax_Revenue_percentage() {
        return tax_Revenue_percentage;
    }

    public void setTax_Revenue_percentage(Double tax_Revenue_percentage) {
        this.tax_Revenue_percentage = tax_Revenue_percentage;
    }

    public Double getTax_recovery_percentage() {
        return tax_recovery_percentage;
    }

    public void setTax_recovery_percentage(Double tax_recovery_percentage) {
        this.tax_recovery_percentage = tax_recovery_percentage;
    }

    public Double getVf() {
        return vf;
    }

    public void setVf(Double vf) {
        this.vf = vf;
    }

    public Double getCf() {
        return cf;
    }

    public void setCf(Double cf) {
        this.cf = cf;
    }
}


