package com.myntra.mfp.entry;

public class Freshness {

    private int new_style;
    private int live_styles;

    public int getNew_style() {
        return new_style;
    }

    public void setNew_style(int new_style) {
        this.new_style = new_style;
    }

    public int getLive_styles() {
        return live_styles;
    }

    public void setLive_styles(int live_styles) {
        this.live_styles = live_styles;
    }
}
