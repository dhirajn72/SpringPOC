package com.myntra.mfp.entry;

/**
 * @Author-Dinesh
 * @Date-4-12-2017
 */


public class Ipp_SOR {

    private Double mrpPerTax;
    private Double bm_Percentage;
    private Double mrp;


    public Double getMrpPerTax() {
        return mrpPerTax;
    }

    public void setMrpPerTax(Double mrpPerTax) {
        this.mrpPerTax = mrpPerTax;
    }

    public Double getBm_Percentage() {
        return bm_Percentage;
    }

    public void setBm_Percentage(Double bm_Percentage) {
        this.bm_Percentage = bm_Percentage;
    }

    public Double getMrp() {
        return mrp;
    }

    public void setMrp(Double mrp) {
        this.mrp = mrp;
    }


}
