/**
 *
 * Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved.
 *
 * MYNTRA PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 **/

package com.myntra.mfp.code;

import com.myntra.commons.codes.ERPErrorCodes;
import com.myntra.commons.codes.StatusCodes;

/**
 * @author Dhiraj
 * @date 23/11/17
 */
public class MfpErrorCode extends ERPErrorCodes {

    private static final String BUNDLE_NAME = "MfpErrorCodes";

    public MfpErrorCode(int code, String message) {

        setAll(code, message, BUNDLE_NAME);
    }

    public static final StatusCodes RECORDS_NOT_FOUND = new MfpErrorCode(22000, "RECORDS_NOT_FOUND");


}



