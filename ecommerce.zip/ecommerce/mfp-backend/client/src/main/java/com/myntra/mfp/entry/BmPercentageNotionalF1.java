package com.myntra.mfp.entry;

public class BmPercentageNotionalF1 {

    private Double ipp;
    private Double vf;
    private Double mrp_ex_tax;

    public Double getIpp() {
        return ipp;
    }

    public void setIpp(Double ipp) {
        this.ipp = ipp;
    }

    public Double getVf() {
        return vf;
    }

    public void setVf(Double vf) {
        this.vf = vf;
    }

    public Double getMrp_ex_tax() {
        return mrp_ex_tax;
    }

    public void setMrp_ex_tax(Double mrp_ex_tax) {
        this.mrp_ex_tax = mrp_ex_tax;
    }
}
