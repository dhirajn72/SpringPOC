package com.myntra.mfp.enums;

public enum UserHirarchy {

    BUSINESS_UNIT("businessUnit"),
    BRANDGROUP("brandGroup"),
    BRAND ("brand"),
    MASTER_CATEGORY("masterCategory"),
    ARTICLE("article"),
    GENDER("gender"),
    PRICE_POINT("pricePoint");


    private final String levelCode;

    UserHirarchy(String levelCode) {
        this.levelCode = levelCode;
    }

    public String getLevelValue() {
        return this.levelCode;
    }
}
