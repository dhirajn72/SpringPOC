package com.myntra.mfp.entry;

/**
 * @Author-Dinesh
 * @Date-4-12-2017
 */


public class RgmUnit {

    private Double gm_percentage;
    private Double aisp;
    private Double tax_percentage;

    public Double getGm_percentage() {
        return gm_percentage;
    }

    public void setGm_percentage(Double gm_percentage) {
        this.gm_percentage = gm_percentage;
    }

    public Double getAisp() {
        return aisp;
    }

    public void setAisp(Double aisp) {
        this.aisp = aisp;
    }

    public Double getTax_percentage() {
        return tax_percentage;
    }

    public void setTax_percentage(Double tax_percentage) {
        this.tax_percentage = tax_percentage;
    }
}
