package com.myntra.mfp.enums;

/**
 * @Author-Dinesh
 * @Date-4-12-2017
 */


public enum Formulas {


    //Inventry Formulas
    NET_UNITS_SOLD("units_sold_in_days-return_restocking-rto_restocking"),
    CLOSING_INV("doh*net_units_sold/120"),
    INWARDED_UNITS("closing_inv-opening_inv+new_units_sold+rtv-ret_restock-rto_restock"),
    STR("gross_units_sold/(gross_units_sold+closing)"),
    FRESHNESS("new_style/live_styles"),


    //Sales Formulas
   // MRP("gmv/(1-discount_percent+tax_recovery_percentage)"),
    MRP("gmv/(1-vf-cf)/(1+tax_recovery_percentage*tax_Revenue_percentage)"),
    UNITS_SOLD("mrp/(mrp/unit)"),
    AISP("gmv/units_sold"),
    MRPEXTAXOR("mrp/(1+tax_percentage)"),
    MRPEXTAXSOR("mrp/(1+tax_percentage)"),
    VF_OR("vf_percentage*mrp"),
    VF_SOR("vf_percentage*ipp"),
    BM_PERCENTAGE_NOTIONAL_SOR("1-(ipp-vf)/mrp_ex_tax"),
    BM_PERCENTAGE_NOTIONAL_OR("1-ipp/mrp_ex_tax"),
    COGS("ipp-vf"),
    GM_PERCENTAGE("1-(cogs*(1+tax_percentage)/gmv)"),
    RGM_UNIT("gm_percentage*aisp/(1+tax_percentage)"),
    IPP_OR("mrpPerTax-bm_Percentage*mrp"),
    IPP_SOR(("mrpPerTax-bm_Percentage*mrp")),
    TAX_OR("gmv*taxRevenuepercentage/(1+taxRevenuepercentage)"),
    TAX_SOR("gmv*taxRevenuepercentage/(1+taxRevenuepercentage)");

    private String formula;

    Formulas(String formula) {
        this.formula = formula;
    }

    public String formula() {
        return formula;
    }
}



