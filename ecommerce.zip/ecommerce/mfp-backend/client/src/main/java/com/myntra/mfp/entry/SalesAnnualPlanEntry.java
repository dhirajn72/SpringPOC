/*
 *
 *  *  Copyright (c) 2017-2025, Myntra and/or its affiliates. All rights reserved. MYNTRA
 *  *  PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *  *
 *
 */

package com.myntra.mfp.entry;

import com.myntra.commons.entries.BaseEntry;

import java.util.Date;

/**
 * @author Dhiraj
 * @date 30/11/17
 */
public class SalesAnnualPlanEntry extends BaseEntry{

    private Double gmv;

    private Double mrp_per_unit;

    private Double aisp;

    private Double cf;

    private Double tax_recovery;

    private Double bm_contractual;

    private String bm_type;

    private Double vf_contractual;

    private Double royalty;

    private Double tax;

    private Double mrp;

    private Double mrp_ex_tax;

    private Double ipp;

    private Double bm_notional;

    private Double cogs;

    private Double gm_percent;

    private int forward_doh;

    private int opening_inventory;

    private int units_sold;

    private int current_inventory;

    private int new_styles_added;

    private int live_styles_month_end;

    private String last_modified_by;

    private Date date_ap;

    private FinalcialYearEntry finalcialYearEntry;

    private ChannelEntry channelEntry;

    private SourceEntry sourceEntry;


    private BusinessUnitEntry businessUnitEntry;

    private BrandGroupEntry brandGroupEntry;

    private BrandEntry brandEntry;

    private MasterCategoryEntry masterCategoryEntry;

    private GenderEntry genderEntry;

    private ArticleEntry articleEntry;

    private CommercialTypeEntry commercialTypeEntry;

    private PricePointEntry pricePointEntry;

    private Double gmv_Ratio;

    public SalesAnnualPlanEntry() {
    }

    public SalesAnnualPlanEntry(Long id, String createdBy, Date createdOn, Date lastModifiedOn, Double gmv, Double mrp_per_unit, Double aisp, Double cf, Double tax_recovery, Double bm_contractual, String bm_type, Double vf_contractual, Double royalty, Double tax, Double mrp, Double mrp_ex_tax, Double ipp, Double bm_notional, Double cogs, Double gm_percent, int forward_doh, int opening_inventory, int units_sold, int current_inventory, int new_styles_added, int live_styles_month_end, String last_modified_by, Date date_ap, FinalcialYearEntry finalcialYearEntry, ChannelEntry channelEntry, SourceEntry sourceEntry, BusinessUnitEntry businessUnitEntry, BrandGroupEntry brandGroupEntry, BrandEntry brandEntry, MasterCategoryEntry masterCategoryEntry, GenderEntry genderEntry, ArticleEntry articleEntry, CommercialTypeEntry commercialTypeEntry , PricePointEntry pricePointEntry) {
        super(id, createdBy, createdOn, lastModifiedOn);
        this.gmv = gmv;
        this.mrp_per_unit = mrp_per_unit;
        this.aisp = aisp;
        this.cf = cf;
        this.tax_recovery = tax_recovery;
        this.bm_contractual = bm_contractual;
        this.bm_type = bm_type;
        this.vf_contractual = vf_contractual;
        this.royalty = royalty;
        this.tax = tax;
        this.mrp = mrp;
        this.mrp_ex_tax = mrp_ex_tax;
        this.ipp = ipp;
        this.bm_notional = bm_notional;
        this.cogs = cogs;
        this.gm_percent = gm_percent;
        this.forward_doh = forward_doh;
        this.opening_inventory = opening_inventory;
        this.units_sold = units_sold;
        this.current_inventory = current_inventory;
        this.new_styles_added = new_styles_added;
        this.live_styles_month_end = live_styles_month_end;
        this.last_modified_by = last_modified_by;
        this.date_ap = date_ap;
        this.finalcialYearEntry = finalcialYearEntry;
        this.channelEntry = channelEntry;
        this.sourceEntry = sourceEntry;
        this.businessUnitEntry = businessUnitEntry;
        this.brandGroupEntry = brandGroupEntry;
        this.brandEntry = brandEntry;
        this.masterCategoryEntry = masterCategoryEntry;
        this.genderEntry = genderEntry;
        this.articleEntry = articleEntry;
        this.commercialTypeEntry=commercialTypeEntry;
        this.pricePointEntry = pricePointEntry;
        this.gmv_Ratio = gmv_Ratio;
    }

    public Double getGmv() {
        return gmv;
    }

    public void setGmv(Double gmv) {
        this.gmv = gmv;
    }

    public Double getMrp_per_unit() {
        return mrp_per_unit;
    }

    public void setMrp_per_unit(Double mrp_per_unit) {
        this.mrp_per_unit = mrp_per_unit;
    }

    public Double getAisp() {
        return aisp;
    }

    public void setAisp(Double aisp) {
        this.aisp = aisp;
    }

    public Double getCf() {
        return cf;
    }

    public void setCf(Double cf) {
        this.cf = cf;
    }

    public Double getTax_recovery() {
        return tax_recovery;
    }

    public void setTax_recovery(Double tax_recovery) {
        this.tax_recovery = tax_recovery;
    }

    public Double getBm_contractual() {
        return bm_contractual;
    }

    public void setBm_contractual(Double bm_contractual) {
        this.bm_contractual = bm_contractual;
    }

    public String getBm_type() {
        return bm_type;
    }

    public void setBm_type(String bm_type) {
        this.bm_type = bm_type;
    }

    public Double getVf_contractual() {
        return vf_contractual;
    }

    public void setVf_contractual(Double vf_contractual) {
        this.vf_contractual = vf_contractual;
    }

    public Double getRoyalty() {
        return royalty;
    }

    public void setRoyalty(Double royalty) {
        this.royalty = royalty;
    }

    public Double getTax() {
        return tax;
    }

    public void setTax(Double tax) {
        this.tax = tax;
    }

    public Double getMrp() {
        return mrp;
    }

    public void setMrp(Double mrp) {
        this.mrp = mrp;
    }

    public Double getMrp_ex_tax() {
        return mrp_ex_tax;
    }

    public void setMrp_ex_tax(Double mrp_ex_tax) {
        this.mrp_ex_tax = mrp_ex_tax;
    }

    public Double getIpp() {
        return ipp;
    }

    public void setIpp(Double ipp) {
        this.ipp = ipp;
    }

    public Double getBm_notional() {
        return bm_notional;
    }

    public void setBm_notional(Double bm_notional) {
        this.bm_notional = bm_notional;
    }

    public Double getCogs() {
        return cogs;
    }

    public void setCogs(Double cogs) {
        this.cogs = cogs;
    }

    public Double getGm_percent() {
        return gm_percent;
    }

    public void setGm_percent(Double gm_percent) {
        this.gm_percent = gm_percent;
    }

    public int getForward_doh() {
        return forward_doh;
    }

    public void setForward_doh(int forward_doh) {
        this.forward_doh = forward_doh;
    }

    public int getOpening_inventory() {
        return opening_inventory;
    }

    public void setOpening_inventory(int opening_inventory) {
        this.opening_inventory = opening_inventory;
    }

    public int getUnits_sold() {
        return units_sold;
    }

    public void setUnits_sold(int units_sold) {
        this.units_sold = units_sold;
    }

    public int getCurrent_inventory() {
        return current_inventory;
    }

    public void setCurrent_inventory(int current_inventory) {
        this.current_inventory = current_inventory;
    }

    public int getNew_styles_added() {
        return new_styles_added;
    }

    public void setNew_styles_added(int new_styles_added) {
        this.new_styles_added = new_styles_added;
    }

    public int getLive_styles_month_end() {
        return live_styles_month_end;
    }

    public void setLive_styles_month_end(int live_styles_month_end) {
        this.live_styles_month_end = live_styles_month_end;
    }

    public String getLast_modified_by() {
        return last_modified_by;
    }

    public void setLast_modified_by(String last_modified_by) {
        this.last_modified_by = last_modified_by;
    }

    public Date getDate_ap() {
        return date_ap;
    }

    public void setDate_ap(Date date_ap) {
        this.date_ap = date_ap;
    }

    public FinalcialYearEntry getFinalcialYearEntry() {
        return finalcialYearEntry;
    }

    public void setFinalcialYearEntry(FinalcialYearEntry finalcialYearEntry) {
        this.finalcialYearEntry = finalcialYearEntry;
    }

    public ChannelEntry getChannelEntry() {
        return channelEntry;
    }

    public void setChannelEntry(ChannelEntry channelEntry) {
        this.channelEntry = channelEntry;
    }

    public SourceEntry getSourceEntry() {
        return sourceEntry;
    }

    public void setSourceEntry(SourceEntry sourceEntry) {
        this.sourceEntry = sourceEntry;
    }

    public BusinessUnitEntry getBusinessUnitEntry() {
        return businessUnitEntry;
    }

    public void setBusinessUnitEntry(BusinessUnitEntry businessUnitEntry) {
        this.businessUnitEntry = businessUnitEntry;
    }

    public BrandGroupEntry getBrandGroupEntry() {
        return brandGroupEntry;
    }

    public void setBrandGroupEntry(BrandGroupEntry brandGroupEntry) {
        this.brandGroupEntry = brandGroupEntry;
    }

    public BrandEntry getBrandEntry() {
        return brandEntry;
    }

    public void setBrandEntry(BrandEntry brandEntry) {
        this.brandEntry = brandEntry;
    }

    public MasterCategoryEntry getMasterCategoryEntry() {
        return masterCategoryEntry;
    }

    public void setMasterCategoryEntry(MasterCategoryEntry masterCategoryEntry) {
        this.masterCategoryEntry = masterCategoryEntry;
    }

    public GenderEntry getGenderEntry() {
        return genderEntry;
    }

    public void setGenderEntry(GenderEntry genderEntry) {
        this.genderEntry = genderEntry;
    }

    public ArticleEntry getArticleEntry() {
        return articleEntry;
    }

    public void setArticleEntry(ArticleEntry articleEntry) {
        this.articleEntry = articleEntry;
    }

    public CommercialTypeEntry getCommercialTypeEntry() {
        return commercialTypeEntry;
    }

    public void setCommercialTypeEntry(CommercialTypeEntry commercialTypeEntry) {
        this.commercialTypeEntry = commercialTypeEntry;
    }

    public PricePointEntry getPricePointEntry() {
        return pricePointEntry;
    }

    public void setPricePointEntry(PricePointEntry pricePointEntry) {
        this.pricePointEntry = pricePointEntry;
    }
}
