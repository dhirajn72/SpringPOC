package com.myntra.mfp.code;

import com.myntra.commons.codes.ERPErrorCodes;

public class AnnualPlanErrorCodes extends ERPErrorCodes {
}
