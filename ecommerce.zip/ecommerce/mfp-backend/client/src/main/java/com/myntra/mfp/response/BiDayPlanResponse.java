package com.myntra.mfp.response;
import com.myntra.commons.codes.StatusResponse;
import com.myntra.commons.response.AbstractResponse;
import com.myntra.mfp.entry.BiDayPlanEntry;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name="biGmvResponse")
public class BiDayPlanResponse extends AbstractResponse {


    private List<BiDayPlanEntry> gmv;

    @XmlElementWrapper(name = "data")
    @XmlElement(name = "gmv")
    public List<BiDayPlanEntry> getgmv() {
        return gmv;
    }

    public final void setData(List<BiDayPlanEntry> gmv) {
        this.gmv = gmv;
        if(getStatus()!=null && gmv != null){
            getStatus().setTotalCount(gmv.size());
        }
    }

    public BiDayPlanResponse() { super();}


    public BiDayPlanResponse(StatusResponse status) {
        super(status);
    }

    public BiDayPlanResponse(List<BiDayPlanEntry> mfpEntry) {
        super();
        setData(mfpEntry);
    }

    @Override
    public String toString() {
        return "BiDayPlanResponse{" +
                "gmv=" + gmv +
                '}';
    }
}
